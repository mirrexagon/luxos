#include <sys/types.h>

void *
memchr(const void *s, int c, size_t n) {
	const unsigned char* us = s;
	unsigned char uc = (unsigned char)c;
	while (n--) {
		if (*us == uc)
			return (void*)us;
		us++;		
	}
	return NULL;
}

