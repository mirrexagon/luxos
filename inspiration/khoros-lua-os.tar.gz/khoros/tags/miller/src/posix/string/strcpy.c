
char*
strcpy(char* s, const char* ct) {
	char* orig = s;
	while ((*s++ = *ct++))
		;
	return orig;
}

