#include <sys/types.h>

void*
memset(void* s, int c, size_t n)
{
	unsigned char* pos;
	unsigned char uc = (unsigned char)c;

	if (!s)
		return s;
	pos = s;

	if (n > 4) {
		unsigned long l;
		l = uc | (uc << 8) | (uc << 16) | (uc << 24);
		while (n >= sizeof(unsigned long)) {
			*(unsigned long*)pos = l;
			n -= sizeof(unsigned long);
			pos += sizeof(unsigned long);
		}
	}

	while (n > 0) {
		*pos = uc;
		pos++;
		n--;
	}

	return s;
}

