#include <string.h>

const char*
strstr(const char* cs, const char* ct) {
	const char* pos = cs;
	if (!cs)
		return 0;
	if (!ct)
		return 0;

	for (;;) {
		pos = strchr(pos, *ct);
		if (!pos)
			return 0;
		if (strcmp(pos, ct) == 0)
			return pos;
		if (!*pos)
			return 0;
		pos++;
	}
}

