#include <sys/types.h>

size_t
strlen(const char* s)
{
	const char* pos;

	if (!s)
		return 0;

	pos = s;
	while (*pos)
		pos++;
	return pos - s;
}

