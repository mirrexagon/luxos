
int
strcmp(const char* cs, const char* ct) {
	int i = 0;
	do {
		i = *cs - *ct;
	} while (!i && *cs++ && *ct++);
	return i;
}

