
char*
strcat(char* s, const char* ct) {
	char* tmp = s;
	while (*tmp)
		tmp++;
	while ((*tmp++ = *ct++))
		;
	return s;
}

