int
isprint(int c) {
	return c >= ' ' && c <= '~';
}
