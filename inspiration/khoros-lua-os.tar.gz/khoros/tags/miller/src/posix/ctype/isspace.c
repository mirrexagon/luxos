
int
isspace(int c) {
	unsigned char uc = (unsigned char)c;
	switch(uc) {
		case '\r':
		case '\n':
		case '\t':
		case ' ':
			return 1;
		default:
			return 0;
	}
}
