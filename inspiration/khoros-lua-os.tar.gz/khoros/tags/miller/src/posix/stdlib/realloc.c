#include <sys/types.h>

#include "bget/bget.h"

void*
realloc(void *ptr, size_t size) {
	return bgetr(ptr, size);
}

