#include <ctype.h>

double
strtod(const char* s, char** endp) {
	double val;
	double sign;

	/* skip whitespace */
	while (*s && isspace(*s))
		s++;

	/* find sign */
	sign = 1;
	if (*s == '-') {
		s++;
		sign = -1;
	}
	else if (*s == '+')
		s++;

	val = 0;
	while (*s && isdigit(*s)) {
		val *= 10;
		val += *s - '0';
		s++;
	}

	if (*s == '.') {
		s++;
		/* TODO */
	}

	*endp = (char*)s;
	return val * sign;
}

