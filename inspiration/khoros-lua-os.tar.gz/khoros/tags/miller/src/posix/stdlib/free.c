#include "bget/bget.h"

void
free(void *ptr) {
	if (ptr)
		brel(ptr);
}

