#include <sys/types.h>

#include "bget/bget.h"

void
__meminit__(void* buf, size_t size) {
	bpool(buf, size);
}

