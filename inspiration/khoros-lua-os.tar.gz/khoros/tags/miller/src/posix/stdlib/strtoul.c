#include <ctype.h>

unsigned long
strtoul(const char* s, char** endp, int base) {
	unsigned long val;
	unsigned long tmp;

	/* skip whitespace */
	while (*s && isspace(*s))
		s++;

	/* find sign */
	if (*s == '+')
		s++;

	if (base == 0) {
		if (s[0] == '0') {
			if (s[1] == 'x' || s[1] == 'X') {
				s += 2;
				base = 16;
			}
			else {
				base = 8;
			}
		}
		else {
			base = 10;
		}
	}

	val = 0;
	while (*s) {
		if (*s >= '0' && *s <= '9')
			tmp = *s - '0';
		else if (*s >= 'a' && *s <= 'z')
			tmp = *s - 'a' + 10;
		else if (*s >= 'A' && *s <= 'Z')
			tmp = *s - 'A' + 10;
		else
			break;

		if (tmp >= base)
			break;
		
		val *= base;
		val += tmp;
		s++;
	}

	*endp = (char*)s;
	return val;
}

