
struct lconv*
localeconv(void) {
	return 0;
}
