/* TODO: check casts, etc. */
double
floor(double d)
{
	int i = d;

	if (d < 0.0 && d != i)
		i--;

	return i;
}

