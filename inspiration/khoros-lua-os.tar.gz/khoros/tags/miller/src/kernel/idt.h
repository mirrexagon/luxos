#ifndef IDT_H
#define IDT_H

#include "regs.h"

void
idt_init(void);

void
idt_set_gate(unsigned char num, unsigned long base, unsigned short sel, unsigned char flags);

#endif

