#ifndef CONSOLE_H
#define CONSOLE_H

void
console_init(void);

void
console_get_pos(unsigned char* x, unsigned char* y);

void
console_set_pos(unsigned char x, unsigned char y);

int
console_draw_char(char c, int x, int y);

int
console_draw_str(const char* s, int x, int y);

int
console_draw_num(unsigned long u, int x, int y);

void
console_clear(void);

#endif

