#ifndef IRQ_H
#define IRQ_H

#include "regs.h"

void
irq_init(void);

void
irq_install_handler(int irq, void (*handler)(struct regs *r, int i));

void
irq_uninstall_handler(int irq);

#endif

