#ifndef TESTS_H
#define TESTS_H

int
run_tests(void);

#endif
