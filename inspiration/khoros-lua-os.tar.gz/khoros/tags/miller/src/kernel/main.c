#include "console.h"
#include "keyboard.h"
#include "gdt.h"
#include "idt.h"
#include "irq.h"
#include "isrs.h"
#include "kernel.h"
#include "multiboot.h"
#include "pmode.h"
#include "tests.h"

#include <stdlib.h>

#define min(x, y) ((x) < (y) ? (x) : (y))

static int
_draw_kb(unsigned long kb, int x, int y)
{
	int i;
	i = 0;
	if (kb > 1024) {
		i += console_draw_num(kb / 1024, x + i, y);
		i += console_draw_str(" MB", x + i, y);
	}
	else {
		i += console_draw_num(kb, x + i, y);
		i += console_draw_str(" KB", x + i, y);
	}
	return x;
}

static void
_show_memory(multiboot_info_t* mbd, int* line)
{
	/* show available memory */
	if (mbd->flags & 1) {
		int x;

		x = 0;
		x += console_draw_str("Lower memory: ", x, *line);
		x += _draw_kb(mbd->mem_lower, x, *line);
		(*line)++;

		x = 0;
		x += console_draw_str("Upper memory: ", x, *line);
		x += _draw_kb(mbd->mem_upper, x, *line);
		(*line)++;
	}
}

static void
_show_mapped_memory(multiboot_info_t* mbd, int* line)
{
	if ((mbd->flags >> 6) & 1) {
		int x;
		unsigned long mmap_addr = mbd->mmap_addr;
		while (mmap_addr < mbd->mmap_addr + mbd->mmap_length) {
			memory_map_t* mmap = (memory_map_t*)mmap_addr;

			x = 0;
			x += console_draw_str("Mapped memory: ", x, *line);
			if (mmap->length_high)
				x += console_draw_str("(too big)", x, *line);
			else
				x += _draw_kb(mmap->length_low / 1024, x, *line);
			(*line)++;

			mmap_addr += mmap->size + sizeof(mmap->size);
 		}
	}

}

void
_main(multiboot_info_t* mbd, unsigned int magic)
{
	int line;
	line = 0;

	console_init();
	console_clear();
	console_draw_str("Copyright (c) 2007 Matthias Miller. All rights reserved.", 0, line++);

	console_draw_str("Initializing gdt...", 0, line++);
	gdt_init();

	console_draw_str("Initializing idt...", 0, line++);
	idt_init();

	console_draw_str("Initializing isrs...", 0, line++);
	isrs_init();

	console_draw_str("Initializing irq...", 0, line++);
	irq_init();

	console_draw_str("Initializing pmode...", 0, line++);
	pmode_init();

	console_draw_str("Enabling interrupts...", 0, line++);
	__asm__ __volatile__ ("sti");

	if (mbd->flags & 1) {
		const int kernel_size = 1024*1024;
		const int max_mem_needed = 50*1024*1024;

		console_draw_str("Initializing bget...", 0, line++);
		__meminit__((void*)(1024*1024 + kernel_size), min(max_mem_needed, mbd->mem_upper * 1024 - kernel_size));
	}

	_show_memory(mbd, &line);
	if (0)
		_show_mapped_memory(mbd, &line);

	/* tests could eventually be run from the kernel */
	if (run_tests())
		console_draw_str("Tests passed", 0, line++);
	else
		console_draw_str("One or more tests failed!", 0, line++);

	console_draw_str("Starting kernel...", 0, line++);
	if (kernel_run() != 0)
		console_draw_str(" > Error starting kernel!", 0, line++);

	console_draw_str("Idling...", 0, line++);
	for (;;)
		;
}
