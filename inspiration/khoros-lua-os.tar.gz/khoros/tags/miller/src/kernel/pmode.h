#ifndef PMODE_H
#define PMODE_H

void
pmode_init(void);

#endif

