#include "tests.h"
#include <setjmp.h>
#include <stdlib.h>

static void
_test_jmp_change_val_and_throw(int* val, int new_val, jmp_buf env, int throw_val)
{
	/* change the value and throw */
	int old_val;
	old_val = *val;
	*val = new_val;
	longjmp(env, throw_val);

	/* restore value in case longjmp fails */
	*val = old_val;
}

static int
test_jmp()
{
	int val, ret;
	jmp_buf env;

	/* try a jump with a throw_val */
	val = 0;
	ret = setjmp(env);
	if (ret == 0)
		_test_jmp_change_val_and_throw(&val, -42, env, 42);
	if (ret != 42 && val != -42)
		return 0;

	/* try a jump no throw_val */
	val = 0;
	ret = setjmp(env);
	if (ret == 0)
		_test_jmp_change_val_and_throw(&val, -42, env, 0);
	if (ret != 1 && val != -42)
		return 0;

	return 1;
}

int
test_strtod()
{
	char* end = "------";
	if (strtod("0", &end) != 0)
		return 0;
	if (*end)
		return 0;

	if (strtod("-1", &end) != -1)
		return 0;
	if (*end)
		return 0;

	if (strtod("42", &end) != 42)
		return 0;
	if (*end)
		return 0;

	if (strtod("8.bogus", &end) != 8)
		return 0;
	if (*end != 'b')
		return 0;

	return 1;
}

int
test_strtoul()
{
	char* end = "________";
	if (strtoul("-1", &end, 0) != 0)
		return 0;
	if (*end != '-')
		return 0;

	if (strtoul("42", &end, 0) != 42)
		return 0;
	if (*end)
		return 0;

	if (strtoul("042", &end, 0) != 34)
		return 0;
	if (*end)
		return 0;

	if (strtoul("0x10", &end, 0) != 16)
		return 0;
	if (*end)
		return 0;

	if (strtoul("FG.bogus", &end, 16) != 15)
		return 0;
	if (*end != 'G')
		return 0;

	return 1;
}

int
run_tests()
{
	int i, ret;
	struct {
		int (*fn)(void);
		const char* name;
	} tests[] = {
		{ test_jmp, "setjmp/longjmp" },
		{ test_strtod, "strtod" },
		{ test_strtoul, "strtoul" }
	};

	ret = 1;
	for (i = 0; i < sizeof(tests)/sizeof(tests[0]); i++) {
		if (!tests[i].fn())
			ret = 0;
	}

	return ret;
}
