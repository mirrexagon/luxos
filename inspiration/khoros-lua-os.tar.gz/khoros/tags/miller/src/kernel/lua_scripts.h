#ifndef LUA_SCRIPTS_H
#define LUA_SCRIPTS_H

#include <sys/types.h>

const char*
get_lua_script(const char* name, size_t* size);

#endif

