#!/usr/bin/python
import os
import sys

def split(sequence, size):
	""" Split up sequence in pieces of size """
	return [sequence[i:i+size] for i in range(0, len(sequence), size)]

def read_files(paths):
	files = []
	for i, path in enumerate(paths):
		files.append({
			'c_name': 'file_%i' % i,
			'lua_name': os.path.splitext(os.path.basename(path))[0],
			'contents': open(path, 'r').read()
		})
	return files

def print_file(c_name, lua_name, contents):
	if not file:
		return

	# Convert the file to hex and remove the trailing comma.
	contents = [hex(ord(char))+', ' for char in contents]
	contents[-1] = contents[-1][:-2]

	print 'static const char %s[] = {' % c_name
	for line in split(contents, 10):
		print '\t', ''.join(line)
	print '};'

def main(paths):
	files = read_files(paths)

	for file in files:
		print_file(**file)

	print """
#include <sys/types.h>
#include <string.h>

const char*
get_lua_script(const char* name, size_t* size) {
	*size = 0;
""",
	for file in files:
		print """
	if (strcmp(name, "%(lua_name)s") == 0) {
		*size = sizeof(%(c_name)s);
		return %(c_name)s;
	}
""" % file,
	print """
	*size = 0;
	return 0;
}
"""

main(sys.argv[1:])
