#ifndef HAS_LUA // BEGIN KERNEL STUB

int
kernel_run(void)
{
	return 0;
}

#else // END KERNEL STUB

#include "console.h"
#include "lua_scripts.h"
#include "irq.h"
#include <queue.h>

#include <lua.h>
#include <lauxlib.h>
#include <lstate.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#define strtoul(a, b, c) (*b = (char*)a, 0)
#define fputs(x, stdout) puts(x)
#include <lauxlib.c>
#include <lbaselib.c>
#include <lstrlib.c>
#include <ltablib.c>
#undef fputs
#undef strtoul

typedef struct Script {
	const char* name;
	int done;
} Script;

static void *
do_alloc(void *ud, void *ptr, size_t osize, size_t nsize)
{
	(void)ud;
	(void)osize;
	if (nsize == 0) {
		free(ptr);
		return NULL;
	}
	else if (osize == 0) {
		return malloc(nsize);
	}
	else {
		return realloc(ptr, nsize);
	}
}


static const char *
get_script(lua_State *L, void *ud, size_t *size)
{
	const char* s;
	Script* p = ud;

	/* check pointers */
	if (!p || !p->name || *p->name != '=') {
		*size = 0;
		return NULL;
	}

	if (p->done)
		return NULL;

	/* check for empty scripts */
	s = get_lua_script(p->name + 1, size);
	if (!s)
		return NULL;
	if (!*size)
		return NULL;

	/* disallow binary */
	if (s[0] == LUA_SIGNATURE[0])
		return NULL;

	p->done = 1;
	return s;
}

static int
traceback (lua_State *L)
{
	puts(lua_tostring(L,-1));
	lua_pop(L,1);
	return 1;
}

static int
exec(lua_State *L, const char* name)
{
	int narg;
	int status;
	int base;
	Script script = { name, 0 };

	status = lua_load(L, get_script, &script, name);
	if (status) {
		puts(lua_tostring(L,-1));
		lua_pop(L,1);
		return status;
	}

	narg = 0;
	base = lua_gettop(L) - narg;  /* function index */
	lua_pushcfunction(L, traceback);  /* push traceback function */
	lua_insert(L, base);  /* put it under chunk and args */
	status = lua_pcall(L, narg, LUA_MULTRET, base);
	lua_remove(L, base);  /* remove traceback function */
	/* force a complete garbage collection in case of errors */
	if (status != 0) lua_gc(L, LUA_GCCOLLECT, 0);
	return status;
}

static int
kernel_load(lua_State* L) {
	const char *name = luaL_checkstring(L, 1);
	luaL_argcheck(L, *name == '=', 1, "name should start with =");

	Script script = { name, 0 };
	int status = lua_load(L, get_script, &script, name);
	if (status == 0)
		return 1;

	lua_pushnil(L);
	lua_insert(L, -2);  /* put before error message */
	return 2;  /* return nil plus error message */
}

static unsigned char
checkuchar(lua_State* L, int narg) {
	int i = luaL_checkint(L, narg);
	luaL_argcheck(L, i >= 0 && i <= (unsigned char)(~0), narg, "out of range; expected unsigned char");
	return (unsigned char)i;
}

static unsigned short
checkushort(lua_State* L, int narg) {
	int i = luaL_checkint(L, narg);
	luaL_argcheck(L, i >= 0 && i < (unsigned short)(~0), narg, "out of range; expected unsigned short");
	return (unsigned short)i;
}

static unsigned long
checkulong(lua_State* L, int narg) {
	double d = luaL_checknumber(L, narg);
	luaL_argcheck(L, d >= 0 && d <= (unsigned long)(~0), narg, "out of range; expected unsigned long");
	return (unsigned long)d;
}

static int
kernel_in8(lua_State* L) {
	if (lua_gettop(L) != 1)
		return luaL_error(L, "wrong number of arguments");
	unsigned short _port = checkushort(L, 1);
	unsigned char result;
	__asm__ ("in %%dx, %%al" : "=a" (result) : "d" (_port));
	lua_pushinteger(L, result);
	return 1;
}

static int
kernel_out8(lua_State* L) {
	if (lua_gettop(L) != 2)
		return luaL_error(L, "wrong number of arguments");
	unsigned short _port = checkushort(L, 1);
	unsigned char _data = checkuchar(L, 2);
	__asm__ ("out %%al, %%dx" : : "a" (_data), "d" (_port));
	return 0;
}

static int
kernel_in16(lua_State* L) {
	if (lua_gettop(L) != 1)
		return luaL_error(L, "wrong number of arguments");
	unsigned short _port = checkushort(L, 1);
	unsigned short result;
	__asm__ ("inw %%dx, %%ax" : "=a" (result) : "d" (_port));
	lua_pushinteger(L, result);
	return 1;
}

static int
kernel_out16(lua_State* L) {
	if (lua_gettop(L) != 2)
		return luaL_error(L, "wrong number of arguments");
	unsigned short _port = checkushort(L, 1);
	unsigned short _data = checkushort(L, 2);
	__asm__ ("outw %%ax, %%dx" : : "a" (_data), "d" (_port));
	return 0;
}

static int
kernel_in32(lua_State* L) {
	if (lua_gettop(L) != 1)
		return luaL_error(L, "wrong number of arguments");
	unsigned short _port = checkushort(L, 1);
	unsigned long result;
	__asm__ ("inl %%dx, %0" : "=a" (result) : "d" (_port));
	lua_pushinteger(L, result);
	return 1;
}

static int
kernel_out32(lua_State* L) {
	if (lua_gettop(L) != 2)
		return luaL_error(L, "wrong number of arguments");
	unsigned short _port = checkushort(L, 1);
	unsigned long _data = checkulong(L, 2);
	__asm__ ("outl %0,%%dx": :"a" (_data), "d" (_port));
	return 0;
}

static int
kernel_draw(lua_State* L) {
	if (lua_gettop(L) != 3)
		return luaL_error(L, "wrong number of arguments");

	int x = luaL_checkint(L, 1);
	luaL_argcheck(L, x >= 1 && x <= 80, 1, "x is out of range");

	int y = luaL_checkint(L, 2);
	luaL_argcheck(L, y >= 1 && y <= 25, 2, "y is out of range");

	const char* s = luaL_checkstring(L, 3);
	luaL_argcheck(L, x + strlen(s) - 1 <= 80, 3, "s is too long");
	console_draw_str(s, x - 1, y - 1);

	return 0;
}

static char _interrupt_queue[1000];
queue_t interrupt_queue = STATIC_BUFFER_QUEUE(_interrupt_queue);

static void
add_interrupt(char num)
{
	if (queue_can_write(&interrupt_queue))
		queue_write(&interrupt_queue, num);
}

static void
interrupt_handler(struct regs *r, int i)
{
	add_interrupt(i);
}

static int
kernel_idle(lua_State* L) {
	__asm__ __volatile__ ("sti; hlt");
	return 0;
}

static int 
kernel_interrupt(lua_State* L) {
	int i = -1;
	__asm__ __volatile__ ("cli");
	if (queue_can_read(&interrupt_queue))
		i = queue_read(&interrupt_queue);
	__asm__ __volatile__ ("sti");

	if (i > -1) {
		lua_pushinteger(L, i);
		return 1;
	}
	return 0;
}

static int
kernel_new_thread(lua_State* L) {
	lua_State *NL;
	luaL_argcheck(L, lua_isfunction(L, 1) && !lua_iscfunction(L, 1), 1,
		"Lua function expected");

	/* optional table */
	if (lua_gettop(L) > 1) {
		luaL_checktype(L, 2, LUA_TTABLE);
		lua_pushvalue(L, 2); /* move table to top */
		if (lua_setfenv(L, 1) == 0)
			luaL_error(L, "unable to set function environment");
	}

	NL = lua_newthread(L);
	lua_pushvalue(L, 1);  /* move function to top */
	lua_xmove(L, NL, 1);  /* move function from L to NL */
	return 1;
}

static void
thread_hook (lua_State *L, lua_Debug *ar) {
	/* Avoid yielding across C calls. This allows atomic code via pcall. */
	if (L->nCcalls) {
		if (lua_gethookcount(L))
			lua_sethook(L, thread_hook, LUA_MASKCOUNT, 0);
	}
	else
		lua_yield(L, 0);
}

/* Creates a new thread.
 * - Returns true when the thread yields.
 * - Returns false, error when the thread ends
 *   Error is nil on success.
 */
static int
kernel_run_thread(lua_State* L) {
	int ret, timeslice;
	lua_State *co;

	co = lua_tothread(L, 1);
	luaL_argcheck(L, co, 1, "coroutine expected");

	timeslice = luaL_checkint(L, 2);
	luaL_argcheck(L, timeslice > 1, 2, "timeslice must be > 1");

	/* TODO: what about child threads? */
	if (lua_gethook(L) == NULL) {
		lua_sethook(co, thread_hook, LUA_MASKCOUNT, timeslice);
		ret = lua_resume(co, 0);
		lua_sethook(co, NULL, 0, 0);
	}
	else {
		ret = lua_resume(co, 0);
	}

	switch (ret) {
	case 0:
		/* done */
		lua_pushboolean(L, 0);
		return 1;
	case LUA_YIELD:
		/* end of timeslice */
		lua_pushboolean(L, 1);
		return 1;
	default:
		lua_xmove(co, L, 1);  /* move error message */
		/* error; could display stack trace */
		lua_pushboolean(L, 0);
		lua_insert(L, -2);
		return 2;
	}
}

typedef struct MemoryBuffer {
	int size;
	unsigned char buffer[1];
} MemoryBuffer;

static MemoryBuffer*
kernel_checkmembuf(lua_State* L, int narg) {
	MemoryBuffer* buffer = luaL_checkudata(L, narg, "kmem");
	luaL_argcheck(L, buffer != NULL, narg, "kmem expected");
	return buffer;
}

static int
kernel_new(lua_State* L) {
	MemoryBuffer* buffer;
	int alloc_size;
	int buffer_size = luaL_checkint(L, 1);
	luaL_argcheck(L, buffer_size > 0, 1, "size must be greater than zero");

	alloc_size = sizeof(MemoryBuffer) + buffer_size -
					sizeof(buffer->buffer);
	buffer = lua_newuserdata(L, alloc_size);
	buffer->size = buffer_size;
	memset(buffer->buffer, '\0', buffer_size);
	luaL_getmetatable(L, "kmem");
	if (lua_setmetatable(L, -2/*buffer*/) == 0)
		luaL_error(L, "unable to set metatable");
	return 1;
}

static int
kmem_size(lua_State* L) {
	MemoryBuffer* buffer = kernel_checkmembuf(L, 1);
	lua_pushinteger(L, buffer->size);
	return 1;
}

static int
kmem_addr(lua_State* L) {
	MemoryBuffer* buffer = kernel_checkmembuf(L, 1);
	lua_pushinteger(L, (unsigned int)buffer->buffer);
	return 1;
}

static int
kmem_get(lua_State* L) {
	MemoryBuffer* buffer = kernel_checkmembuf(L, 1);
	int offset = luaL_checkint(L, 2);
	luaL_argcheck(L, offset > 0 && offset <= buffer->size, 2,
		"offset is out of range");
	lua_pushinteger(L, buffer->buffer[offset-1]);
	return 1;
}

static int
kmem_set(lua_State* L) {
	MemoryBuffer* buffer = kernel_checkmembuf(L, 1);
	int offset = luaL_checkint(L, 2);
	unsigned char data = checkuchar(L, 3);

	luaL_argcheck(L, offset > 0 && offset <= buffer->size, 2,
		"offset is out of range");
	buffer->buffer[offset-1] = data;
	return 1;
}

static const luaL_Reg
kernellib[] = {
	{"load", 	kernel_load},
	{"in8",		kernel_in8},
	{"in16",	kernel_in16},
	{"in32",	kernel_in32},
	{"out8",	kernel_out8},
	{"out16",	kernel_out16},
	{"out32",	kernel_out32},
	{"draw",	kernel_draw},
	{"idle",	kernel_idle},
	{"interrupt", kernel_interrupt},
	{"new_thread", kernel_new_thread},
	{"run_thread", kernel_run_thread},
	{"new",		kernel_new},
	{NULL,	NULL}
};

static const luaL_Reg
kmemlib[] = {
	{"size",	kmem_size},
	{"addr",	kmem_addr},
	{"get",		kmem_get},
	{"set",		kmem_set},
	{NULL, NULL}
};

static void
luaopen_kmem(lua_State* L) {
	luaL_newmetatable(L, "kmem");
	lua_pushvalue(L, -1);  /* push metatable */
	lua_setfield(L, -2, "__index");  /* metatable.__index = metatable */
	luaL_register(L, NULL, kmemlib);  /* kmem methods */
}

int
kernel_run(void)
{
	lua_State* L;
	int status;
	const char* name;
	int i;

	name = "??";

	for (i = 0; i < 16; i++)
		irq_install_handler(i, interrupt_handler);

	L = lua_newstate(do_alloc, NULL);
	if (!L)
		return 1;
	/* todo: if (lua_atpanic(L, &panic); */
	luaopen_base(L);
	luaopen_table(L);
	luaopen_string(L);
	luaopen_kmem(L);
	luaL_register(L, "c_kernel", kernellib);

	status = exec(L, "=kernel");
	lua_close(L);
	return status;
}

#endif

