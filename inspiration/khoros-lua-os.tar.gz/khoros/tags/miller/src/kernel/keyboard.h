#ifndef KEYBOARD_H
#define KEYBOARD_H

int
keyboard_has_pending(void);

char
keyboard_get(void);

#endif

