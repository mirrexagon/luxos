#include "keyboard.h"
#include <queue.h>

static char _keyboard_queue[100];
static struct {
        queue_t queue;
} keyboard = {
        STATIC_BUFFER_QUEUE(_keyboard_queue)
};

static void
keyboard_fill_buffer(void)
{
        /*
	TODO
        while (queue_can_write(&keyboard.queue) && inb(0x64) != 0)
                queue_write(&keyboard.queue, inb(0x60));
        */
}

int
keyboard_has_pending(void)
{
        keyboard_fill_buffer();
        return queue_can_read(&keyboard.queue);
}

char
keyboard_get(void)
{
        if (!queue_can_read(&keyboard.queue))
                return '\0';
        return queue_read(&keyboard.queue);
}

