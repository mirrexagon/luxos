#include "console.h"

static struct {
	volatile unsigned short* const crtc_base_addr;
	volatile unsigned short const crtc_base_mono;
	volatile unsigned short const crtc_base_vga;
	volatile unsigned char* const mono;
	volatile unsigned char* const vga;
	const int num_cols;
	const int num_rows;

	volatile unsigned char* current;
} console = {
	(unsigned short*)0x0463,
	0x3B4,
	0x3D4,
	(unsigned char*)0xb0000,
	(unsigned char*)0xb8000,
	80,
	25,

	0x0,
};

static unsigned char
in(unsigned short _port) {
	unsigned char result;
	__asm__ ("in %%dx, %%al" : "=a" (result) : "d" (_port));
	return result;
}

static void
out(unsigned short _port, unsigned char _data) {
	__asm__ ("out %%al, %%dx" : : "a" (_data), "d" (_port));
}

void
console_init(void)
{
	if (*console.crtc_base_addr == console.crtc_base_vga)
		console.current = console.vga;
	else
		console.current = console.mono;
}

void
console_get_pos(unsigned char* x, unsigned char* y) {
	unsigned short pos;
	out(0x3D4, 14);
	pos = in(0x3D5) << 8;
	out(0x3D4, 15);
	pos |= in(0x3D5);
	if (x)
		*x = pos % 80;
	if (y)
		*y = pos / 80;
}

void
console_set_pos(unsigned char x, unsigned char y) {
	unsigned short pos = y * 80 + x;
	out(0x3D4, 14);
	out(0x3D5, (unsigned char)(pos >> 8));
	out(0x3D4, 15);
	out(0x3D5, (unsigned char)(pos));
}

int
console_draw_char(char c, int x, int y)
{
	if (x < 0 || x >= console.num_cols)
		return 0;
	if (y < 0 || y >= console.num_rows)
		return 0;
	console.current[(x + 80*y) * 2] = c;
	return 1;
}

int
console_draw_str(const char* s, int x, int y)
{
	int i;
	for (i = 0; s[i]; i++)
		console_draw_char(s[i], x+i, y);
	return i;
}

static int
num_digits(unsigned long u)
{
	int digits;
	digits = 0;

	do {
		digits++;
		u /= 10;
	} while (u);

	return digits;
}

int
console_draw_num(unsigned long u, int x, int y)
{
	int digits;
	digits = 0;

	/* go from right to left */
	x += num_digits(u) - 1;
	do {
		digits += console_draw_char('0' + (u % 10), x--, y);
		u /= 10;
	} while (u);

	return digits;
}

void
console_clear(void)
{
	int x, y;
	for (x = 0; x < console.num_cols; x++)
		for (y = 0; y < console.num_rows; y++)
			console_draw_char(' ', x, y);
}

