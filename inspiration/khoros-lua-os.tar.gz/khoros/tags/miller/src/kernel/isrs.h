#ifndef ISRS_H
#define ISRS_H

void
isrs_init(void);

#endif

