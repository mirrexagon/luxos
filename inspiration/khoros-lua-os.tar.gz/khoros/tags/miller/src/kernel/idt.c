/* bkerndev - Bran's Kernel Development Tutorial
*  By:   Brandon F. (friesenb@gmail.com)
*  Desc: Interrupt Descriptor Table management
*
*  Notes: No warranty expressed or implied. Use at own risk. */
#include "idt.h"
#include <string.h>

/* Declare an IDT of 256 entries. Although we will only use the
*  first 32 entries in this tutorial, the rest exists as a bit
*  of a trap. If any undefined IDT entry is hit, it normally
*  will cause an "Unhandled Interrupt" exception. Any descriptor
*  for which the 'presence' bit is cleared (0) will generate an
*  "Unhandled Interrupt" exception */
static struct
{
	unsigned short base_lo;
	unsigned short sel;
	unsigned char always0;
	unsigned char flags;
	unsigned short base_hi;
} __attribute__((packed)) idt[256];

/* Installs the IDT */
void
idt_init(void)
{
	/* Clear out the entire IDT, initializing it to zeros */
	memset(&idt, 0, sizeof(idt));

	/* Add any new ISRs to the IDT here using idt_set_gate */

 	/* Points the processor's internal register to the new IDT */
	struct idt_ptr {
		unsigned short limit;
		unsigned int base;
	} __attribute__((packed)) idtp = {
		sizeof (idt) - 1,
		idtp.base = (int)&idt
	};
	asm("lidt (%0)": : "r"(&idtp));
}

/* Use this function to set an entry in the IDT. Alot simpler
*  than twiddling with the GDT ;) */
void
idt_set_gate(unsigned char num, unsigned long base, unsigned short sel, unsigned char flags)
{
	/* The interrupt routine's base address */
	idt[num].base_lo = (base & 0xFFFF);
	idt[num].base_hi = (base >> 16) & 0xFFFF;

	/* The segment or 'selector' that this IDT entry will use
	*  is set here, along with any access flags */
	idt[num].sel = sel;
	idt[num].always0 = 0;
	idt[num].flags = flags;
}

