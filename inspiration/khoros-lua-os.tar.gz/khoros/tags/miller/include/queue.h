#ifndef QUEUE_H
#define QUEUE_H

#include <sys/types.h>

typedef struct queue_t {
	char* buffer;
	size_t len, read, write;
} queue_t;

#define STATIC_BUFFER_QUEUE(buffer) { (buffer), sizeof(buffer), 0, 0 }

static inline int
queue_get_next(queue_t* q, size_t i) {
	return (i + 1) % q->len;
}

static inline int
queue_get_len(queue_t* q) {
	return (q->len + q->write - q->read) % q->len;
}

static inline int
queue_can_read(queue_t* q) {
	return q->read != q->write;
}

static inline int
queue_can_write(queue_t* q) {
	return queue_get_next(q, q->write) != q->read;
}

static inline void
queue_write(queue_t* q, char c) {
	if (!queue_can_write(q))
		return;
	q->buffer[q->write] = c;
	q->write = queue_get_next(q, q->write);
}

static inline char
queue_read(queue_t* q) {
	char c;
	if (!queue_can_read(q))
		return '\0';
	c = q->buffer[q->read];
	q->read = queue_get_next(q, q->read);
	return c;
}

#endif
