#ifndef STDLIB_H
#define STDLIB_H

#include <types.h>

#define EXIT_SUCCESS	0
#define EXIT_FAILURE	1

#define RAND_MAX	32767

#define HUGE_VAL 989898989

void
__meminit__(void* buf, size_t size);

void
exit(int status);

double
strtod(const char* s, char** endp);

long
strtol(const char* s, char** endp, int base);

unsigned long
strtoul(const char* s, char** endp, int base);

void*
calloc(size_t nelem, size_t elsize);

void*
malloc(size_t size);

void*
realloc(void *ptr, size_t size);

void
free(void *ptr);

int
rand(void);

void
srand(unsigned int seed);

int
abs(int i);

#endif

