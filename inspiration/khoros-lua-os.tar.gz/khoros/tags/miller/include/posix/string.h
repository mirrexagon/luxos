#ifndef STRING_H
#define STRING_H

#include <types.h>

const char*
strchr(const char* s, int c);

size_t
strlen(const char* s);

char*
strcpy(char* s, const char* ct);

char*
strncpy(char* s, const char* ct, int n);

char*
strcat(char* s, const char* ct);

char*
strncat(char* s, const char* ct, int n);

int
strcmp(const char* cs, const char* ct);

size_t
strcspn(const char* cs, const char* ct);

const char*
strstr(const char* cs, const char* ct);

void*
memcpy(void* s1, const void* s2, size_t n);

int
memcmp(const void *s1, const void *s2, size_t n);

int
strcoll(const char *s1, const char *s2);

void *
memchr(const void *s, int c, size_t n);

void*
memset(void* s, int c, size_t n);

char *
strpbrk(const char *s1, const char *s2);

char*
strrchr(const char *s, int c);

#endif
