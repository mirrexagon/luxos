#ifndef MATH_H
#define MATH_H

#define MATH_ERRNO	1
#define MATH_ERREXCEPT	2

#define math_errhandling MATH_ERRNO

double
floor(double x);

double
pow(double x, double y);

#endif

