#ifndef LIMITS_H
#define LIMITS_H

#define INT_MAX		2147483647
#define UCHAR_MAX	255
#define SHRT_MAX	32767

#endif

