#ifndef SYS_TYPES_H
#define SYS_TYPES_H

#define NULL	0
typedef unsigned long size_t;

#endif

