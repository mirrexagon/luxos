#ifndef STDIO_H
#define STDIO_h

#include <types.h>

#define BUFSIZ  512

int
sprintf(char* s, const char* format, ...);

int
printf(const char* format, ...);

int
puts(const char* str);

#endif

