#ifndef STDDEF_H
#define STDDEF_H

#include <types.h>

typedef long int ptrdiff_t;

#endif

