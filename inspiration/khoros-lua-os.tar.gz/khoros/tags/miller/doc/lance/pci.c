/*
 * pci.c
 *	Simplistic functions for accessing PCI
 */

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <mach/io.h>
#include <sys/mman.h>

#include "pci.h"

int
pci_rw(int bus, int dev, int func, int reg, int size, int wr, int val)
{
    int caddr, addr, ret;

    caddr = CONFADDR(1, bus, dev, func, reg & 0xfc);
    addr = PciCONFDATA + (reg & 3);
    outportl(PciCONFADD, caddr);

    ret = 0;
    switch(size) {
    case 1: 
        if(wr)
	    outportb(addr, val);
	else
            ret = inportb(addr);
	break;
    case 2: 
        if(wr)
	    outportw(addr, val);
	else
            ret = inportw(addr);
	break;
    case 4: 
        if(wr)
	    outportl(addr, val);
	else
            ret = inportl(addr);
	break;
    default:
        assert(0);
    }
    outportl(PciCONFADD, 0);
    return ret;
}

int
pci_read(struct pcidev *pci, int reg, int size)
{
    return pci_rw(pci->bus, pci->dev, pci->func, reg, size, 0, 0);
}

int
pci_write(struct pcidev *pci, int reg, int size, int val)
{
    return pci_rw(pci->bus, pci->dev, pci->func, reg, size, 1, val);
}

/*
 * scan pci looking for vid/did match. Call cb on success
 */
int 
pcimatch(int targvid, int targdid, void (*cb)(struct pcidev *pci))
{
    struct pcidev pci;
    int bus, dev, cnt;
    ushort vid, did;

    cnt = 0;
    for(bus = 0; bus < 8; bus++) {
        for(dev = 0; dev < 32; dev++) {
	    vid = pci_rw(bus, dev, 0, PciVID, 2, 0, 0);
	    did = pci_rw(bus, dev, 0, PciDID, 2, 0, 0);
	    if(vid != targvid || did != targdid)
	        continue;
            cnt++;
	    pci.bus = bus;
	    pci.dev = dev;
	    pci.func = 0;
	    pci.iobase = pci_rw(bus, dev, 0, PciIOBASE, 4, 0, 0) & 0xfff0;
	    pci.intno = pci_rw(bus, dev, 0, PciINT, 1, 0, 0);
	    pci.pin = pci_rw(bus, dev, 0, PciPIN, 1, 0, 0);
	    cb(&pci);
        }
    }
    return cnt;
}

static struct pcidev sbridge;

static void
foundsbridge(struct pcidev *pci)
{
    sbridge = *pci;
}

static int
pIIxget(struct pcidev *pci, int off)
{
    uchar x = pci_read(pci, off, 1);
    return (x < 16) ? x : 0;
}

static void
pIIxset(struct pcidev *pci, int off, int val)
{
    pci_write(pci, off, 1, val);
}

// check the pci interrupt routing.  This is somewhat of a quick
// and dirty hack right now.
void
pciroute(struct pcidev *pci)
{
    struct router {
        uchar sig[4];
	uchar vers[2];
	uchar size[2];
	uchar bus;
	uchar dev;
	short irqs;
	uchar compat[4];
	uchar miniport[4];
	uchar res[11];
	uchar cksum;
    };
    struct ent {
        uchar bus;
	uchar dev;
	uchar maps[12];
	uchar slot;
	uchar res;
    };
    struct router *r;
    struct ent *ent, *entbase;
    uchar *addr;
    int i, irq, map, size;

    if(pci->intno == -1)
        return;

    // search for the pIIx explicitely... this is a hack
    if(pcimatch(0x8086, 0x7110, foundsbridge) != 1) {
        syslog(LOG_ERR, "couldnt find the south bridge\n");
	exit(1);
    }

    addr = mmap((void*)0xf0000, 0x10000, PROT_READ|PROT_WRITE, MAP_PHYS, 0, 0L);
    if(!addr) {
        syslog(LOG_ERR, "cant map bios\n");
	exit(1);
    }
    for(i = 0; i < 0x10000; i+= 16) {
        if(memcmp(addr + i, "$PIR", 4) == 0)
	    break;
    }
    if(i == 0x10000) {
        syslog(LOG_ERR, "cant find PCI routing\n");
	exit(1);
    }
    
    syslog(LOG_INFO, "routing pin %d (int %d)\n", pci->pin, pci->intno);

    // look for an entry matching this device
    r = (struct router*)(addr + i);
    entbase = (struct ent*)(r + 1);
    size = r->size[0] | (r->size[1] << 8);
    size /= sizeof *ent;
    for(i = 0; i < size; i++) {
        ent = &entbase[i];
        if(ent->bus != pci->bus || (ent->dev >> 3) != pci->dev)
	    continue;
        map = ent->maps[(pci->pin - 1) * 3];
        irq = pIIxget(&sbridge, map);
	if(irq == 0 || irq == pci->intno)
	    continue;
	pIIxset(&sbridge, map, pci->intno);
	pci_write(pci, PciINT, 1, irq);
	pci->intno = irq;
	syslog(LOG_INFO, "route pin %d to irq %d\n", pci->pin, pci->intno);
    }
    munmap(addr, 0x10000);
    return;
}

/* enable or disable bus mastering */
void
pcibusmaster(struct pcidev *pci, int en)
{
    int x;

    x = pci_read(pci, PciCMD, 2);
    if(en)
        x |= PciBME;
    else
        x &= ~PciBME;
    pci_write(pci, PciCMD, 2, x);
}

