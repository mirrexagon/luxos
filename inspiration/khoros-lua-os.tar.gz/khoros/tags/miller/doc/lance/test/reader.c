
#include <fcntl.h>
#include <unistd.h>

int
main()
{
    uchar buf[1500];
    char *name;
    int fd, len, i, cnt;

    name = "/lance/0";
    fd = open(name, O_RDONLY);
    if(fd == -1) {
        perror(name);
	exit(1);
    }

    cnt = 1;
    while((len = read(fd, buf, sizeof buf)) >= 0) {
        printf("%d: got %d bytes\n", cnt++, len);
        for(i = 0; i < len; i++) {
	    printf("%02x ", buf[i]);
	}
	printf("\n");
    }
    perror("read");
    return 0;
}

