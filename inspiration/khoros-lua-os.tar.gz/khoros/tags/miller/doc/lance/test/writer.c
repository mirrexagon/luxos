
#include <fcntl.h>
#include <unistd.h>

int
main()
{
    uchar buf[14 + 8];
    char *name;
    int fd, len, i, cnt;

    name = "/lance/0";
    fd = open(name, O_WRONLY);
    if(fd == -1) {
        perror(name);
	exit(1);
    }

    cnt = 1;
    for(;;) {
        for(i = 0; i < sizeof buf; i++)
	    buf[i] = i;
        len = write(fd, buf, sizeof buf);
        printf("%d: wrote %d bytes\n", cnt++, len);
	if(len != 0)
	    break;
	sleep(1);
    }
    perror("write");
    return 0;
}

