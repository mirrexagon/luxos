#!/bin/sh

umount /lance
mount net/lance /lance
./reader

