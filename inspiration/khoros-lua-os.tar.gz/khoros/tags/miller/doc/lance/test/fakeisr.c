
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/msg.h>
#include <sys/fs.h>

#define PATH "/lance"
#define NAME "net/lance"

int
main(int argc, char **argv)
{
    char buf[10], *pname;
    port_t port;
    port_name name;
    struct msg m;
    int fd, wtime;

    pname = NAME;
    wtime = 1000;
    if(argc >= 2)
        pname = argv[1];
    if(argc >= 3)
        wtime = atoi(argv[2]);
    printf("using %s %.3f\n", pname, wtime / 1000.0);
    name = namer_find(pname);
    if(name == -1) {
        perror(pname);
	exit(1);
    }

    port = msg_connect(name, ACC_WRITE | ACC_READ | ACC_NOCLONE);
    if(port == -1) {
        perror("connect");
	exit(1);
    }
printf("port is %d\n", port);

    for(;;) {
        memset(&m, 0, sizeof m);
        m.m_op = 200 | M_READ;
	m.m_buf = buf;
	m.m_buflen = 2;
	m.m_arg = m.m_buflen = 2;
	m.m_arg1 = 0;
	m.m_nseg = 1;

	//printf("msg send %d %p\n", port, &m);
	__msleep(wtime);
	msg_send(port, &m);
    }
}

