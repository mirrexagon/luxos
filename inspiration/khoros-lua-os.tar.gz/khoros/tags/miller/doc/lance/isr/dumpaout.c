
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <mach/aout.h>

static void
dump(char *fname)
{
    unsigned char buf[1024 * 16];
    struct aout hdr;
    FILE *fp;
    int len, i;

    fp = fopen(fname, "r");
    if(!fp) {
        perror(fname);
	exit(1);
    }
    if(fread(&hdr, sizeof hdr, 1, fp) != 1) {
        fprintf(stderr, "bad header\n");
	exit(1);
    }
    if(hdr.a_text == 0 || hdr.a_data != 0 || hdr.a_bss != 0) {
        fprintf(stderr, "expected text only\n");
	exit(1);
    }
    if(hdr.a_text > sizeof buf) {
        fprintf(stderr, "text is too big\n");
	exit(1);
    }
    printf("int entry = %d;\n", (int)(hdr.a_entry - sizeof hdr - 0x1000));

    len = hdr.a_text;
    if(fread(buf, len, 1, fp) != 1) {
        fprintf(stderr, "short read\n");
        exit(1);
    }
    while(buf[len-1] == 0)
        len--;

    printf("unsigned char code[] = {");
    for(i = 0; i < len; i++) {
	if(i % 8 == 0)
	    printf("\n    ");
        printf("0x%02x, ", buf[i]);
    }
    printf("\n};\n");
    fclose(fp);
    return;
}

int
main(int argc, char **argv)
{
    int i;

    for(i = 1; argv[i]; i++) {
        dump(argv[i]);
    }
    return 0;
}

