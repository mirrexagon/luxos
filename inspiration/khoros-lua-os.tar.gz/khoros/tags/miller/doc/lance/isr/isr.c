
#define BIT(n)		(1 << (n))
#define RDP		0x10
#define RAP		0x14
#define INTR		BIT(7)
#define IENA		BIT(6)

/*
 * inportl()
 *	Get a word from an I/O port
 */
static unsigned int
inportl(int port)
{
	register unsigned int res;
	
	__asm__ __volatile__(
		"inl %%dx,%%eax\n\t"
		: "=a" (res)
		: "d" (port));
	return(res);
}

/*
 * outportl()
 *	Write a word to an I/O port
 */
static void
outportl(int port, unsigned int data)
{
	__asm__ __volatile__(
		"outl %%eax,%%dx\n\t"
		: /* No output */
		: "a" (data), "d" (port));
}

static int 
read_csr0(int base)
{
    int x, rap;

    rap = inportl(base + RAP);
    outportl(base + RAP, 0);
    x = inportl(base + RDP);
    outportl(base + RAP, rap);
    return x;
}

static void 
write_csr0(int base, int val)
{
    int rap;

    rap = inportl(base + RAP);
    outportl(base + RAP, 0);
    outportl(base + RDP, val);
    outportl(base + RAP, rap);
}

/*
 * entry point - process interrupts for all pci-lance's listed in bases[]
 */
int
proc_intr(int *basep)
{
    int i, b, ret;

    ret = 0;
    i = 0;
    b = 1;
    while(*basep) {
        // if interrupt happened, clear interrupt enable and take note
        if(read_csr0(*basep) & INTR) {
	    // clear the IENA bit
	    write_csr0(*basep, 0);
	    ret |= b;
	}
	b <<= 1;
	basep++;
    }
    return ret;
}

