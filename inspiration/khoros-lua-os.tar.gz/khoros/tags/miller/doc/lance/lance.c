/*
 * lance.c
 *	Access to the 79c970 pci/lance chip
 *
 * Tim Newsham - Oct 7 2002
 * Public Domain
 */

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <syslog.h>
#include <signal.h>
#include <sys/param.h>
#include <sys/syscall.h>
#include <sys/mman.h>
#include <sys/msg.h>
#include <mach/io.h>
#include <minifs.h>

#include "pci.h"
#include "ether.h"
#include "lance.h"

#include "isr/code.h"

// ring sizes
// note: the kernel has a limit on how many pages can be wired down
// so this value cannot be too big
#define RLENlog	3	// 2^RLEN = number of read buffers in ring
#define TLENlog	3	// 2^TLEN = number of write buffers in ring
#define RLEN	(1 << RLENlog)
#define TLEN	(1 << TLENlog)

// because we need to do page-wiring, we can only get NBPG (4k)
// of contiguous physical memory.  We can only fit 2 fullsize
// MTU's into this buffer, so we just set our ring buffer sizes to 2k,
// and waste the extra (2048 - (1500 + 4)) - 544 bytes per buffer.
#define RBSIZE	2048
#define ETHERMTU 1500
#if RBSIZE < ETHERMTU + 4
#error "code assumes RBSIZE can hold an MTU"
#endif

/* local prototypes */
static void interrupt(struct msg *m);

// A 79c970 ethernet adapter 
struct adapter {
    struct pcidev pci;
    void *physaddr;		// physical address of this struct
    int physhand;		// handle on the phys addr
    struct InitBlock iblock;
    struct RingDescr rring[RLEN];
    struct RingDescr tring[TLEN];
    uchar eaddr[6];
    uint ridx;			// rring index 
    uint tidx;			// tring index where we're putting
    uint tidx2;			// tring index of what's been sent
    uint pending;		// number of tx buffers pending
    struct err {
        int merr, miss, babl;
	int frame, crc, oflow, buf;
    } err;
};

#define NEXTINDEX(idx, size)	(((idx) + 1) % (size))

// the physical address of any item in the device structure
#define DEVPHYS(d, f)	\
    (uint)((char *)&(d)->f - (char *)(d) + (char *)(d)->physaddr)

/* driver globals */
struct minifs fs;
struct adapter *adapters[MAXADAPTERS] = { 0 };
int nadapters = 0;

static void *
xmalloc(int len)
{
    void *ret;

    if((ret = malloc(len)) == 0) {
        syslog(LOG_ERR, "out of memory!\n");
	exit(1);
    }
    return ret;
}

static void
found79c970(struct pcidev *pci)
{
    struct adapter *dev;

    if(nadapters >= MAXADAPTERS) {
        syslog(LOG_INFO, "only %d device supported, ignoring new device\n", 
	       MAXADAPTERS);
	return;
    }

    // we allocate the device onto a page thats wired down
    assert(sizeof *dev <= NBPG);
    dev = xmalloc(NBPG);
    memset(dev, 0, NBPG);
    dev->physhand = page_wire(dev, &dev->physaddr, 0);
    if(dev->physhand == -1) {
        syslog(LOG_ERR, "pagewire failed\n");
	exit(1);
    }

    dev->pci = *pci;
    adapters[nadapters++] = dev;
    return;
}

static int
lance_read(struct adapter *dev, int off, int size)
{
    assert(size == 2 || size == 4);
    switch(size) {
    case 2:
        return inportw(LANCEADDR(dev->pci.iobase, off, size));
	break;
    case 4:
        return inportl(LANCEADDR(dev->pci.iobase, off, size));
	break;
    default:
        assert(0);
	return 0;
    }
}

static void
lance_write(struct adapter *dev, int off, int size, int val)
{
    assert(size == 2 || size == 4);
    switch(size) {
    case 2:
        outportw(LANCEADDR(dev->pci.iobase, off, size), val);
	break;
    case 4:
        outportl(LANCEADDR(dev->pci.iobase, off, size), val);
	break;
    default:
        assert(0);
    }
}

static int
lance_readcsr(struct adapter *dev, int reg, int size)
{
    lance_write(dev, Rap, 4, reg);
    return lance_read(dev, Rdp, size);
}

static void
lance_writecsr(struct adapter *dev, int reg, int size, int val)
{
    lance_write(dev, Rap, 4, reg);
    lance_write(dev, Rdp, size, val);
}

static int
lance_readbcr(struct adapter *dev, int reg, int size)
{
    lance_write(dev, Rap, 4, reg);
    return lance_read(dev, Bdp, size);
}

static void
lance_writebcr(struct adapter *dev, int reg, int size, int val)
{
    lance_write(dev, Rap, 4, reg);
    lance_write(dev, Bdp, size, val);
}

// allocate the memory needed by the ring
static void
initring(struct RingDescr *r, int size, int flags1)
{
    void *buf, *bufphys;
    uint i, blen;

    // allocate buffers out of pages until done
    i = 0;
    while(i < size) {
	blen = NBPG;
        buf = xmalloc(blen);
	memset(buf, 0, blen);
	if(page_wire(buf, &bufphys, 0) == -1) {
	    syslog(LOG_ERR, "page_wire failed\n");
	    exit(1);
        }

	while(i < size && blen >= RBSIZE) {
	    r[i].addr = bufphys;
	    r[i].flags1 = flags1;
	    r[i].buf = buf;

	    buf += RBSIZE;
	    bufphys += RBSIZE;
	    blen -= RBSIZE;
	    i++;
	}
    }
}

static int
init79c970(struct adapter *dev)
{
    int bases[2];
    int x, i;

    // XXX enable_io for the port range in dev->pci ?

    // read from the reset port, then write a 32-bit val to
    // Rdp to put it into 32-bit mode
    lance_read(dev, Reset, 4);
    lance_read(dev, Reset, 2);
    lance_write(dev, Rdp, 4, 0);

    // verify that it worked
    if(lance_readcsr(dev, Csr0, 4) != Stop) {
        syslog(LOG_ERR, "init failed\n");
	return -1;
    }

    // check out the chip id
    x = lance_readcsr(dev, ChipId, 4);
    switch(x) {
    case 0x2420003: syslog(LOG_INFO, "chip 79c970 id %x\n", x); break;
    case 0x2621003: syslog(LOG_INFO, "chip 79c970A id %x\n", x); break;
    default:
        syslog(LOG_ERR, "unkown chip id %x\n", x);
	return -1;
    }

    bases[0] = dev->pci.iobase;
    bases[1] = 0;
    if(minifs_enableisr(&fs, interrupt, dev->pci.intno, code, sizeof code, 
       bases, sizeof bases) == -1) {
        syslog(LOG_ERR, "failed to enable isr");
	return -1;
    }

    pcibusmaster(&dev->pci, 1);

    // software-style 2: 32-bit data structures
    lance_writecsr(dev, SoftStyle, 4, 0x2);
    // turn on auto-pad-transmit feature
    lance_writecsr(dev, Features, 4, lance_readcsr(dev, Features, 4) | BIT(11));
    // auto-select media
    //lance_writebcr(dev, 20, 4, lance_readbcr(dev, 20, 4) | BIT(1));

    for(i = 0; i < 6; i++) {
        dev->eaddr[i] = inportl(dev->pci.iobase + i);
    }
    syslog(LOG_INFO, " MAC Addr: %02x.%02x.%02x.%02x.%02x.%02x\n",
           dev->eaddr[0], dev->eaddr[1], dev->eaddr[2],
           dev->eaddr[3], dev->eaddr[4], dev->eaddr[5]);

    // setup the initialization block and the rings
    memcpy(dev->iblock.padr, dev->eaddr, sizeof dev->eaddr);
    dev->iblock.rlen = RLENlog << 4;
    dev->iblock.tlen = TLENlog << 4;
    dev->iblock.rdra = DEVPHYS(dev, rring[0]);
    dev->iblock.tdra = DEVPHYS(dev, tring[0]);
    initring(dev->rring, RLEN, Own | (-RBSIZE & 0xffff));
    initring(dev->tring, TLEN, 0);
    lance_writecsr(dev, IblockAddr, 4, DEVPHYS(dev, iblock) & 0xffff);
    lance_writecsr(dev, IblockAddr+1, 4, (DEVPHYS(dev, iblock) >> 16) & 0xffff);

    // ignore Idon interrupts, init the chip, wait for it, and then start it
    // with interupts enabled
    lance_writecsr(dev, Imask, 4, Idon);
    lance_writecsr(dev, Csr0, 4, Init);
    while(! (lance_readcsr(dev, Csr0, 4) & Idon)) {
        __msleep(10);
    }
    lance_writecsr(dev, Csr0, 4, Iena | Strt);

    return 0;
}

static int
stop79c970(struct adapter *dev)
{
    lance_read(dev, Reset, 4);
    lance_read(dev, Reset, 2);
    pcibusmaster(&dev->pci, 0);
    return 0;
}

// signal termination
static void
stop(int sig)
{
    int i;

    for(i = 0; i < nadapters; i++) {
        stop79c970(adapters[i]);
    }
    exit(0);
}

uchar *
ether_getaddr(int unit)
{
    return adapters[unit]->eaddr;
}

int
ether_tx_busy(int unit)
{
    return (adapters[unit]->pending >= TLEN);
}

// queue a buffer for transmission
// call only when there's room for the buffer!
void
ether_start(int unit, struct msg *m)
{
    struct adapter *dev = adapters[unit];
    struct RingDescr *ringdesc;
    uint seg, left, len, slen;

    // take possession of the next transmit ring buffer
    assert(dev->pending < TLEN);
    ringdesc = &dev->tring[dev->tidx];
    dev->tidx = NEXTINDEX(dev->tidx, TLEN);
    dev->pending++;

    // Copy as much of the msg into the ring buffer as will fit
    len = 0;
    left = ETHERMTU;
    for(seg = 0; left > 0 && seg < m->m_nseg; seg++) {
        slen = MIN(m->m_seg[seg].s_buflen, left);
	memcpy(ringdesc->buf + len, m->m_seg[seg].s_buf, slen);
	len += slen;
	left -= slen;
    }

    // and pass ownership over to the lance
    ringdesc->flags2 = 0;
    ringdesc->flags1 = Own | Start | End | (-len & 0xffff);
    lance_writecsr(dev, Csr0, 4, Iena | Tdmd);
}

static void
interrupt(struct msg *m)
{
    struct adapter *dev;
    int unit = 0;
    int csr0, len;

    // just one unit right now
    dev = adapters[unit];
    for(;;) {
    	// read and clear all interrupts
    	csr0 = lance_readcsr(dev, Csr0, 4);
    	lance_writecsr(dev, Csr0, 4, 
                   	Babl | Cerr | Idon | Merr | Miss | Rint | Tint | Iena);
	
    	if(csr0 & Babl)
        	dev->err.babl++;
    	if(csr0 & Merr)
        	dev->err.merr++;
    	if(csr0 & Miss)
        	dev->err.miss++;
    	if(!(csr0 & (Rint | Tint)))
        	return;

    	if(csr0 & Rint) {
	    // consume ring buffers that have been received
	    for(;;) {
	        struct RingDescr *rent = &dev->rring[dev->ridx];
		if(rent->flags1 & Own)
		    break;

		len = (rent->flags2 & 0x7ff) - 4;
                if(rent->flags1 & RingErr) {
		    if(rent->flags1 & FrameErr)
		        dev->err.frame++;
                    if(rent->flags1 & OflowErr)
		        dev->err.oflow++;
                    if(rent->flags1 & CrcErr)
		        dev->err.crc++;
                    if(rent->flags1 & BufErr)
		        dev->err.buf++;
		} else if(len > 0) {
		    ether_send_up(rent->buf, len, 0);
		}

		// give the buffer back to the device.
		// note: we leave the addr/buf the same
		rent->flags2 = 0;
		rent->flags1 = Own | (-RBSIZE & 0xffff);

		dev->ridx = NEXTINDEX(dev->ridx, RLEN);
            }
    	}

    	if(csr0 & Tint) {
	    // reclaim ring buffers that have already been sent
	    while(dev->pending) {
	        if(dev->tring[dev->tidx2].flags1 & Own)
		    break;
	        dev->tidx2 = NEXTINDEX(dev->tidx2, TLEN);
		dev->pending--;
	    }

	    // populate the transmit ring if there's more data
	    ether_run_queue(unit);
    	}
    }
}

int
main()
{
    openlog("lance", LOG_PID, LOG_DAEMON);

    enable_dma(0);
    enable_io(PciCONFADD, PciCONFADD + 8);
    if(pcimatch(0x1022, 0x2000, found79c970) == 0) {
        syslog(LOG_ERR, "device not found\n");
	exit(1);
    }

    signal(SIGINT, stop);
    signal(SIGTERM, stop);
    ether_init();
    if(minifs_init(&fs, 0, "net/lance", &ether_prot) == -1)
        exit(1);
    fs.creat = ether_creat;

    // looks like its already routed... grub?
    //pciroute(&adapters[0]->pci);
    if(init79c970(adapters[0]) == -1)
        exit(1);

    for(;;)
        minifs_dispatch(&fs);
    return 0;
}

