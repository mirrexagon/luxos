/*
 * ether.h
 *	Interface to VSTa system for ethernet drivers
 */

#include <llist.h>
#include <sys/perm.h>

/*
 * ethernet header
 */
struct ether_header {
    uchar ether_dhost[6];
    uchar ether_shost[6];
    uchar ether_type[2];
};

#define MAXADAPTERS	1

// globals
extern struct prot ether_prot;
extern struct llist writers[MAXADAPTERS];
extern struct llist files;
extern ulong dropped;

// prototypes
void ether_init(void);
struct minifs_file *ether_creat(struct minifs_client *c, char *name, int mode);
void ether_run_queue(int unit);
int ether_send_up(char *buf, int len, int retrans);
void ether_start(int unit, struct msg *m);
int ether_tx_busy(int unit);
uchar *ether_getaddr(int unit);

