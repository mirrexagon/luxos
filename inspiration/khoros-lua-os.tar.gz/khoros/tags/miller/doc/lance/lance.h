/*
 * lance.h
 *	79c970 registers and driver definitions
 */

// i/o offsets from 0x10 for lance bus registers, in word units
enum {
    Rdp = 0x0,		// register data port - CSRx access through Rap/Rdp
    Rap = 0x1,		// register address port
    Reset = 0x2,	// read to reset
    Bdp = 0x3,		// BCR data port - BCRx access through Rap/Bdp
};

#define LANCEADDR(base, off, size)	((base) + 0x10 + (off) * (size))

// CSR0 bits
enum {
    Init = BIT(0),
    Strt = BIT(1),
    Stop = BIT(2),
    Tdmd = BIT(3),
    Txon = BIT(4),
    Rxon = BIT(5),
    Iena = BIT(6),
    Intr = BIT(7),
    Idon = BIT(8),
    Tint = BIT(9),
    Rint = BIT(10),
    Merr = BIT(11),
    Miss = BIT(12),
    Cerr = BIT(13),
    Babl = BIT(14),
    Err = BIT(15)
};

// CSRx registers
enum {
    Csr0 = 0,			// status register
    IblockAddr = 1,		// init block address
    Imask = 3,			// interrupt masks and deferral 
    Features = 4,		// test and features control
    SoftStyle = 58,		// software style, alias for BCR20
    ChipId = 88,		// chip id
};

// the initialization block, in 32-bit layout - 32-bit aligned
struct InitBlock {
    ushort mode;		// mode as in CSR15
    uchar rlen;			// note: upper four bits
    uchar tlen;			// note: upper four bits
    uchar padr[6];		// ethernet address
    uchar pad1[2];
    uchar laddr[8];		// logical address filter
    uint rdra;			// xmit/rcv ring descrptors - 16-byte aligned
    uint tdra;
};

// ring descriptor
struct RingDescr {
    void *addr;			// buffer address
    uint flags1;		// flags and the Bcnt field
    uint flags2;		// Rcc and Rpc fields
    uchar *buf;			// steal resvd field to store virtual addr
};

// ring flags1
enum {
    Own = BIT(31),
    RingErr = BIT(30),
    FrameErr = BIT(29),
    AddFcs = BIT(29),		// set fcs when writing
    OflowErr = BIT(28),
    CrcErr = BIT(27),
    BufErr = BIT(26),
    Start = BIT(25),
    End = BIT(24),
};


