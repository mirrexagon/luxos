/*
 * ether.c
 *	Generic ethernet service functions
 */

#include <stdio.h>
#include <sys/fs.h>
#include <sys/assert.h>
#include <std.h>
#include <llist.h>
#include <minifs.h>

#include "ether.h"

#define MAXQUEUE (64)		/* Max packets we buffer for our clients */

/* pack and extract (unit,proto) */
#define UNITPROTO(u, p)		(((u) << 16) | (p))
#define UNIT(n)			((n) >> 16)
#define PROTO(n)		((n) & 0xffff)

/* local prototypes */
static void ether_open(struct minifs_client *c);
static void ether_close(struct minifs_client *c);
static void ether_abort(struct minifs_client *c);
static void ether_read(struct minifs_client *c, struct msg *m);
static void ether_write(struct minifs_client *c, struct msg *m);
static void ether_stat(struct minifs_client *c, char *buf, int len);
static void ether_wstat(struct minifs_client *c, struct msg *m, char *field, char *val);

/*
 * Queued data for later readers
 */
struct bufq {
	void *q_buf;
	int q_len;
	struct llist *q_queue;
};

/*
 * client queues
 */
struct llist writers[MAXADAPTERS];	/* Who's waiting on each unit */
struct llist readers;			/* Who's waiting for input */
struct llist files;
ulong dropped = 0;			/* # packets without reader */
static struct llist rxqueue;		/* Queued receive packets */
static int nrxqueue;			/*  ...# in queue */
void *pak_pool;				/* Packet memory for queueing receive */

/* Protection for ether hierarchy..  */
struct prot ether_prot = {
	2, 0,
	{1, 1}, {ACC_READ, ACC_WRITE|ACC_CHMOD}
};

/* dispatch for ethernet files */
struct fdispatch ether_disp = {
	ether_open, ether_close,
	ether_abort, 0,
	ether_read, ether_write,
	ether_stat, ether_wstat
};

/* extra per-client info attached to minifs_client */
struct ether_client {
	struct llist *e_io;		/* position in read or write queue */
	struct msg e_msg;		/* pending request */
};

/*
 * put_16be
 *	Put a sixteen bit number into a short in big-endian format
 */
static void
put_16be(uchar *targ, short val)
{
    targ[0] = val >> 8;
    targ[1] = val & 0xff;
}

/*
 * get_16be
 * 	Get a sixteen bit number from a short in big-endian format
 */
static short
get_16be(uchar *src)
{
    return (src[0] << 8) & src[1];
}

/*
 * ether_creat
 *	Handle a client's attempt to create a file
 *
 * We don't check for ACC_CREATE.. allowing a create whenever a user
 * tries to access a non-existant file.
 */
struct minifs_file *
ether_creat(struct minifs_client *c, char *name, int mode)
{
    struct minifs_file *newf;
    char *endp;
    int x;

    if(minifs_access(c, &ether_prot, mode) == -1)
        return NULL;

    /* file name must be a number */
    x = strtoul(name, &endp, 10);
    if(endp == name || *endp || x < 0 || x > 0xffff)
        return NULL;

    /* make the file */
    newf = minifs_makefile(c->c_file, name, &ether_disp, &ether_prot, 0);
    if(newf) {
        /* record the unit and proto and mark it for auto-deletion */
        newf->data = (void*)UNITPROTO(0, x);
	newf->f_refs --;
    }
    return newf;
}

/* notification: client opened a ethertype file */
static void
ether_open(struct minifs_client *c)
{
    struct ether_client *ec;

    ec = malloc(sizeof *ec);
    if(ec)
        ec->e_io = 0;
    c->data = ec;
}

/* notification: client closed a ethertype file */
static void
ether_close(struct minifs_client *c)
{
    if(c->data)
        free(c->data);
}

static void
ether_abort(struct minifs_client *c)
{
    struct ether_client *ec = (struct ether_client *)c->data;

    if(ec)
    	return;
    if(ec->e_io) {
    	ll_delete(ec->e_io);
	ec->e_io = 0;
    }
}

/*
 * ether_run_queue()
 *	If there's stuff in writers queue, launch next
 */
void
ether_run_queue(int unit)
{
	struct minifs_client *c;
	struct ether_client *ec;

	/*
	 * Nobody waiting--adapter falls idle
	 */
	if (writers[unit].l_forw == &writers[unit]) {
		return;
	}

	/*
	 * Remove next from list
	 */
	c = writers[unit].l_forw->l_data;
	ec = (struct ether_client *)c->data;
	ASSERT_DEBUG(ec && ec->e_io, "ether_run_queue: on queue !e_io");
	ll_delete(ec->e_io);
	ec->e_io = 0;

	/*
	 * Launch I/O
	 */
	ether_start(unit, &ec->e_msg);

	/*
	 * Success.
	 */
	ec->e_msg.m_arg = 0;
	ec->e_msg.m_nseg = 0;
	ec->e_msg.m_arg1 = 0;
	msg_reply(ec->e_msg.m_sender, &ec->e_msg);
}

/*
 * rw_init()
 *	Initialize our queue data structures
 */
void
ether_init(void)
{
	int unit;

	for(unit = 0; unit < MAXADAPTERS; unit++) {
		ll_init(&writers[unit]);
	}
	ll_init(&readers);
	ll_init(&rxqueue);
}

/*
 * ether_write()
 *	Write to an open file
 */
void
ether_write(struct minifs_client *c, struct msg *m)
{
	struct minifs_file *f = c->c_file;
	struct ether_client *ec = (struct ether_client *)c->data;
	int unit = UNIT((int)f->data);

	if(!ec) {
		msg_err(m->m_sender, ENOMEM);
		return;
	}

	/* must be opened for writing */
	if (!(c->c_mode & ACC_WRITE)) {
		msg_err(m->m_sender, EPERM);
		return;
	}

	/*
	 * Queue write, fail if we can't insert list element (VM
	 * exhausted?)
	 */
	ASSERT_DEBUG(ec->e_io == 0, "ether_write: busy");
	ec->e_io = ll_insert(&writers[unit], c);
	if (ec->e_io == 0) {
		msg_err(m->m_sender, strerror());
		return;
	}
	ec->e_msg = *m;
	ec->e_msg.m_arg = 0;

	if (!ether_tx_busy(unit)) {
		ether_run_queue(unit);
	}

	return;
}

/*
 * ether_read()
 *	Read bytes out of the current attachment or directory
 */
void
ether_read(struct minifs_client *c, struct msg *m)
{
	struct ether_client *ec = (struct ether_client *)c->data;

	if(!ec) {
		msg_err(m->m_sender, ENOMEM);
		return;
	}

	/*
	 * Access?
	 */
	if (!(c->c_mode & ACC_READ) || !ec) {
		msg_err(m->m_sender, EPERM);
		return;
	}

	/*
	 * Queue as a reader
	 */
	ASSERT_DEBUG(ec->e_io == 0, "ether_read: busy");
	ec->e_io = ll_insert(&readers, c);
	if (ec->e_io == 0) {
		msg_err(m->m_sender, strerror());
		return;
	}
	ec->e_msg = *m;

	/*
	 * If there's queued packets, run through them
	 */
	if (nrxqueue) {
		struct llist *l = LL_NEXT(&rxqueue);
		struct bufq *q = l->l_data;

		/*
		 * If we pushed it up, free the resources
		 */
		if (!ether_send_up(q->q_buf, q->q_len, 1)) {
			/*
			 * Put the packet body on our local pool
			 */
			*(void **)q->q_buf = pak_pool;
			pak_pool = q->q_buf;

			/*
			 * Delete us from the rxqueue list
			 */
			ll_delete(l);
			free(q);

			/*
			 * And update the length of that list
			 */
			nrxqueue -= 1;
		}
	}
}

/*
 * ether_send_up()
 *	Send received packet to requestor(s)
 *
 * Given a buffer containing a received packet, walk the list of pending
 * readers and return packet if a matching type is found.  If none is
 * found, the packet is dropped.
 * len is length of packet data, excluding header, type and checksum.
 *
 * Returns 0 if buffer may be reused; 1 if a it will be held and
 * free()'ed later.
 *
 * XXX right now this always returns 0 because the lance driver
 * wants to keep its own buffers seperate.  Fix the lance driver to
 * eliminate the extra copy?
 */
int
ether_send_up(char *buf, int len, int retrans)
{
	struct llist *l, *ln;
	struct ether_header *eh;
	ushort etype;
	int sent;
	struct bufq *q;

	/*
	 * Fast discard for null packets
	 */
	if (len == 0) {
		return(0);
	}

	/*
	 * Walk pending reader list
	 */
	eh = (struct ether_header *)buf;
	etype = get_16be(eh->ether_type);
	sent = 0;
	for (l = LL_NEXT(&readers); l != &readers; l = ln) {
		struct minifs_client *c;
		struct ether_client *ec;
		ushort t2;

		/*
		 * Get next pointer now, before we might delete
		 */
		ln = LL_NEXT(l);
		c = l->l_data;

		/* get private data - must be present if on readers q */
		ec = (struct ether_client *)c->data;
		ASSERT_DEBUG(ec, "ether_send_up: missing client data");

		/*
		 * Give him the packet if he wants all (type 0) or
		 * has the right type open.
		 */
		t2 = PROTO((int)c->c_file->data);
		if (!t2 || (t2 == etype)) {
			struct msg *m;

			m = &ec->e_msg;
			if (m->m_nseg == 0) {
				/*
				 * He didn't provide a buffer, send
				 * him ours.
				 */
				m->m_nseg = 1;
				m->m_buf = buf;
				m->m_buflen = len;
			} else {
				/*
				 * Otherwise copy out our buffer to
				 * his (we're a DMA server) and go
				 * on.
				 */
				m->m_nseg = 0;
				m->m_buflen = MIN(m->m_buflen, len);
				memcpy(m->m_buf, buf, m->m_buflen);
			}
			m->m_arg = m->m_buflen;
			m->m_arg1 = 0;
			msg_reply(m->m_sender, m);
			ll_delete(l);
			ASSERT_DEBUG(ec->e_io == l, "ether_send_up: mismatch");
			ec->e_io = 0;
			sent += 1;
		}
	}

	/*
	 * It was consumed; let him continue with the buffer.
	 */
	if (sent) {
		return(0);
	}

	/*
	 * If this is already in our queue, don't bother re-queueing
	 */
	if (retrans) {
		return(1);
	}

	/*
	 * Nobody consumed it; make a copy unless we're too far
	 * ahead.
	 */
	if (nrxqueue > MAXQUEUE) {
		dropped += 1;
		return(0);
	}

	/*
	 * Queue it.
	 */
	nrxqueue += 1;
	q = malloc(sizeof(struct bufq));
	q->q_buf = malloc(len);
	memcpy(q->q_buf, buf, len);
	q->q_len = len;
	q->q_queue = ll_insert(&rxqueue, q);
	return(0);
}

/*
 * ether_stat
 *	Return ethernet specific status fields
 */
static void
ether_stat(struct minifs_client *c, char *buf, int len)
{
	struct ether_client *ec = (struct ether_client *)c->data;
	struct llist *l, *lstart;
	uchar *addr;
	uint size, unit;

	unit = UNIT((int)c->c_file->data);
	if(!ec)
		return;

	/*
	 * Calculate length of write queue
	 */
	size = 0;
	lstart = &writers[unit];
	for (l = LL_NEXT(lstart); l != lstart; l = LL_NEXT(l)) {
		struct msg *m2;
		uint y;

		m2 = l->l_data;
		for (y = 0; y < m2->m_nseg; ++y) {
			size += m2->m_seg[y].s_buflen;
		}
	}

	// XXX we should report additional card stats here
	// such as framing, checksum and other errors
	addr = ether_getaddr(unit);
	sprintf(buf, "size=%d\nmacaddr=%02x.%02x.%02x.%02x.%02x.%02x\n",
		size, addr[0], addr[1], addr[2], addr[3], addr[4], addr[5]);
}

/*
 * ether_wstat
 *	Handle ethernet specific stat writes
 */
void
ether_wstat(struct minifs_client *c, struct msg *m, char *field, char *val)
{
	struct ether_client *ec = (struct ether_client *)c->data;
	uint tmp, unit;

	unit = UNIT((int)c->c_file->data);
	if(!ec)
		return;

	/*
	 * Process each kind of field we can write
	 */
	if (!strcmp(field, "type")) {
		/* Set attachment type */
		sscanf(val, "%x", (uint *)&tmp);
		c->c_file->data = (void *)UNITPROTO(unit, tmp);
	} else {
		msg_err(m->m_sender, EINVAL);
		return;
	}
	m->m_buflen = m->m_nseg = m->m_arg = m->m_arg1 = 0;
	msg_reply(m->m_sender, m);
}

