/*
 * pci.h
 *	PCI definitions
 *
 * Taken from the intel 440BX spec sheet
 */

#define BIT(x)		(1 << (x))

// conf address composition: (en 1, reserved 7, bus 8, dev 5, func 3, reg 8)
#define CONFADDR(en, bus, dev, func, reg)    \
    (((en) << 31) | ((bus) << 16) | ((dev) << 11) | ((func) << 8) | (reg))

// i/o mapped registers
enum {
    PciCONFADD = 0xcf8,
    PciCONFDATA = 0xcfc,
    PciPM2 = 0x022,
};

// PCI registers available through CONFADD/CONFDATA
enum {
    PciVID = 0x00,		// vendor id - 16 ro
    PciDID = 0x02,		// device id - 16 ro
    PciCMD = 0x04,		// command - 16 rw
    PciSTS = 0x06,		// status - 16 rwc
    PciRID = 0x08,		// revision id - 8 ro
    PciSUBC = 0x0a,		// subclass code - 8 ro
    PciBCC = 0x0b,		// baseclass code - 8 ro
    PciMLT = 0x0d,		// master latency timer - 8 rw
    PciHDR = 0x0e,		// header type - 8 ro
    PciIOBASE = 0x10,		// IO base - 32 rw
    PciMEMBASE = 0x14,		// Memory base - 32 rw
    PciINT = 0x3c,		// interrupt line - 8 rw
    PciPIN = 0x3d,		// interupt pin - 8
};

// PciCMD bits
enum {
    PciBME = BIT(2),		// bus master enable
};


// information about a pci device
struct pcidev {
    int bus, dev, func;
    int iobase, intno, pin;
};

// prototypes

// these two never made it into <mach/io.h> but are in libc
uint inportl(int port);
void outportl(int port, uint val);

int pci_rw(int bus, int dev, int func, int reg, int size, int wr, int val);
int pci_read(struct pcidev *pci, int reg, int size);
int pci_write(struct pcidev *pci, int reg, int size, int val);
int pcimatch(int targvid, int targdid, void (*cb)(struct pcidev *pci));
void pciroute(struct pcidev *pci);
void pcibusmaster(struct pcidev *pci, int en);

