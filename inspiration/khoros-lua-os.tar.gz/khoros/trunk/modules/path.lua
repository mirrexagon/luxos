-- $Id: $

-- Copyright (c) 2009, Matthias Miller, Jörg Zinke (developers@khoros.org)
-- All rights reserved.
--
-- Redistribution and use in source and binary forms, with or without
-- modification, are permitted provided that the following  conditions
-- are met:
--
--    - Redistributions of source code must retain the above copyright
--      notice, this list of conditions and the following disclaimer.
--    - Redistributions in binary form must reproduce the above
--      copyright notice, this list of conditions and the following
--      disclaimer in the documentation and/or other materials provided
--      with the distribution.
--    - Neither the name of the khoros team nor the names of its
--      contributors may be used to endorse or promote products derived
--      from this software without specific prior written permission.
--
-- THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
-- "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
-- LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
-- FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
-- COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
-- INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
-- BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
-- LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
-- CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
-- LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
-- ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
-- POSSIBILITY OF SUCH DAMAGE.

-- path module

-- todo: - fix directory() and filename() expressions

module(..., package.seeall)

require("string")

require("filesystem")

-- absolute path
function absolute(path)
    local directory = nil
    local normalize = nil

    assert(type(path) == "string", "path is not a string")
    assert(string.len(path) > 0, "path length zero")

    -- check if absolute path is given
    if not string.match("^/", path) then
        -- prepend working directory
        directory = filesystem.working_directory()
        path = directory .. "/" .. path
    end

    -- normalize a path
    -- a//b and a/./b and a/foo/../b become a/b

    -- replace dots in path
    normalize = string.gsub(path, "(/%./)", "/")

    -- replace double dots in path
    normalize = string.gsub(normalize, "([^/]+/%.%.)", "")

    -- replace multiple slashes with single slash
    normalize = string.gsub(normalize, "(/+)", "/")

    return normalize
end

-- directory of given path
-- different from the behavior of dirname()
function directory(path)
    local name = nil

    assert(type(path) == "string", "path is not a string")
    assert(string.len(path) > 0, "path length zero")

    -- directory name
    name = string.match(path, "^(.+)/") or "." -- does not work with: "/"

    return name
end

-- extension of a given path
function extension(path)
    local name = nil
    local extension = nil

    assert(type(path) == "string", "path is not a string")
    assert(string.len(path) > 0, "path length zero")

    -- set name and extension
    name, extension = string.match(path, "(.*)%.([^.]*)$")

    -- pattern match returns nil if no dot is found in path
    name = name or path
    extension = extension or ""

    return name, extension
end

-- filename of given path
-- different from the behavior of basename()
function filename(path)
    local name = nil

    assert(type(path) == "string", "path is not a string")
    assert(string.len(path) > 0, "path length zero")

    -- cut everything except the filename
    name = string.gsub(path, "^(.+/)", "") -- does not work with: "/foo"

    return name
end

-- split path
function split(path)
    local components = {}

    assert(type(path) == "string", "path is not a string")
    assert(string.len(path) > 0, "path length zero")

    -- split path into components
    for component in string.gmatch(s, "[^/]+") do
        table.insert(components, component)
    end

    return components
end
