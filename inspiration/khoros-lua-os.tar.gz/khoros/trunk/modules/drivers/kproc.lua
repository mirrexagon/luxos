-- This is a generic multithreading module. To init, load the module.
-- It returns a table with three functions:
-- * init
-- 		This function receives two function callbacks:
-- 		newthread, which creates a thread:
-- 			thread = newthread(func, {
-- 				ipc = ...
-- 			})
--
--		runthread, which runs a thread, returning false upon completion
-- 			runthread(thread, name)
--
--		For simplistic threading without timeslicing, simply call:
--			init(coroutine.create, coroutine.resume)
--
-- * spawn
-- 		Creates a new thread for "fn"
--
-- * run
-- 		Services all threads
--
local newthread = nil
local runthread = nil
local function init(newthread_, runthread_)
	assert(newthread_, 'missing newthread')
	assert(runthread_, 'missing runthread')
	newthread = newthread_
	runthread = runthread_
end

-- Converts a function into an atomic call
local function atomic(func)
	return function(...)
		-- This would be better implemented as a C function
		-- for the sake of debugging.
		local ret, val = pcall(func, unpack(arg))
		if ret then
			return val
		else
			error(val)
		end
	end
end

local processes = {}
local function spawn(procname, func)
	if processes[procname] ~= nil then
		error('Duplicate process name: ' .. procname)
	end

	local nextmsgid = 0
	local process
	local function matches_args(message, args)
		return (args.from == nil or args.from == message.from) and
				(args.name == nil or args.name == message.name) and
				(args.replytoid == nil or args.replytoid == message.replytoid)
	end
	local function find_message(table, args)
		for key, value in pairs(table) do
			if matches_args(value, args) then
				return key, value
			end
		end
	end
	local ipc
	local function _internal_send(to, replytoid, name, value)
		if processes[to] == nil then
			error('No such process: ' .. to)
		end
		if to == procname then
			error('Cannot send messages to self: ' .. to)
		end
		local msgid = nextmsgid
		nextmsgid = nextmsgid + 1
		local message = {
			from = procname,
			to = to,
			msgid = msgid,
			replytoid = replytoid,
			name = name,
			value = value
		}
		table.insert(processes[to].messages, message)

		-- Try to unblock the process
		if processes[to].blocking then
			if matches_args(message, processes[to].blocking) then
				processes[to].blocking = nil
				assert(not processes[to].blocking)
			end
		end

		return {
			msgid = msgid,
			recv_async = (function()
				return ipc.recv_async{replytoid = msgid}
			end),
			recv = (function()
				return ipc.recv{replytoid = msgid}
			end)
		}
	end
	ipc = {
		-- Sends a message to a process.
		-- Returns: response message
		send = atomic(function(to, name, value)
			return _internal_send(to, nil, name, value)
		end),
		-- Checks for a message, given:
		--  - replytoid: response to a message
		--  - name: message name
		--  - from: message sender
		recv_async = atomic(function(args)
			local key, value = find_message(process.messages, args)
			if key ~= nil then
				-- Remove the first one and return it.
				table.remove(process.messages, key)

				-- Save values to avoid tampering!
				local from = value.from
				local msgid = value.msgid
				local name = value.name
				value.reply = atomic(function(value)
					return _internal_send(from, msgid, name, value)
				end)

				return value
			end
		end),
		recv = function(args)
			local value = atomic(function()
				assert(not process.blocking)
				key, value = find_message(process.messages, args)
				-- No such message. Block until the message is received.
				if key then
					return assert(ipc.recv_async(args))
				else
					process.blocking = args
				end
			end)()
			if value then
				return value
			end

			coroutine.yield()
			return assert(atomic(function()
				return ipc.recv_async(args)
			end)())
		end,
		subscribe = function(args)
			-- TODO: add assertion for args
			table.insert(process.subscriptions, args)
		end,
		broadcast = function(name, value)
			local message = { from = procname, name = name }
			for other_procname, other_process in pairs(processes) do
				if other_procname ~= procname then
					-- Check the subscriptions for this process.
					for ignored, wanted_msg in pairs(other_process.subscriptions) do
						if matches_args(message, wanted_msg) then
							-- Send it and bail out.
							ipc.send(other_procname, name, value)
							break
						end
					end
				end
			end
		end,
	}

	if not newthread then
		error('kproc has not been initialized.')
	end
	process = {
		thread = newthread(func, { ipc = ipc }, procname),
		blocking = nil,
		messages = {},
		subscriptions = {},
	}
	assert(process.thread)
	processes[procname] = process
end

local function runproc(name)
	local process = processes[name]
	-- Not all processes are live.
	if process.thread and not process.blocking then
		local ret = runthread(process.thread, name)
		if ret then
			return true
		else
			processes[name] = nil
		end
	end

	return false
end

local function run()
	local alive = 0
	for name, process in pairs(processes) do
		if runproc(name) then
			alive = alive + 1
		end
	end
	return alive
end

local function make_ipc(name)
	assert(name, 'missing name')
	local _old = newthread
	local ipc
	newthread = function(fn, args)
		ipc = args.ipc
		return true
	end
	spawn(name, function()
		ipc.recv{ from = name }
	end)
	newthread = _old
	-- Permanently block the process
	processes[name].thread = nil
	return ipc	
end

return {
	atomic = atomic,
	init = init,
	make_ipc = make_ipc,
	spawn = spawn,
	run = run,
	runproc = runproc,
	has = atomic(function(name)
		return processes[name] ~= nil
	end)
}

