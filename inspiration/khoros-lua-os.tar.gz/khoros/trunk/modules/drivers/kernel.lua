-- Don't let other modules access the C kernel.
local _c_kernel = c_kernel
c_kernel = nil
kernel = {
	draw = _c_kernel.draw,
	in8 = _c_kernel.in8,
	in16 = _c_kernel.in16,
	in32 = _c_kernel.in32,
	out8 = _c_kernel.out8,
	out16 = _c_kernel.out16,
	out32 = _c_kernel.out32,
	new = _c_kernel.new,
	new_thread = _c_kernel.new_thread,
	run_thread = _c_kernel.run_thread,
	reboot = function()
		kernel.out8(100, 254)
	end
}

local TIMESLICE = 1000

do
	local fn, err = _c_kernel.load('=util')
	assert(fn, err)()

	local fn, err = _c_kernel.load('=kproc')
	local kproc = assert(fn, err)()
	kproc.init(function(fn, args, procname)
		args.assert = assert
		args.tostring = tostring
		-- args.puts = puts
		args.kernel = kernel -- TODO
		args.register_interrupt = register_interrupt
		args.unpack = unpack
		-- args.print = print
		args.ipairs = ipairs
		args.table = table
		args.type = type
		args.loadstring = loadstring
		args.pcall = pcall -- TODO

		local function wrapper(...)
			setfenv(0, args)

			local util, err = _c_kernel.load('=util')
			assert(util, err)()
			return fn(unpack(arg))
		end

		return kernel.new_thread(wrapper)
	end,
	function(thread, procname)
		ret, err = kernel.run_thread(thread, TIMESLICE)
		if not ret and err ~= nil then
			print('Process exited with error.\n' .. err)
			while true do end -- TODO
		end
		return ret
	end
	)

	-- Load ipc for the kernel.
	ipc = kproc.make_ipc('kernel')

	-- Load tty
	kproc.spawn('tty', function()
		local fn, err = _c_kernel.load('=tty')
		assert(fn, err)()
	end)

	-- Redefine puts in the kernel to flush
	do
		local _puts = puts
		puts = function(...)
			_puts(unpack(arg))
			while kproc.runproc('tty') do
			end
		end
	end

	-- Output a blank string to force a flush.
	puts('')

	do
		local function load_module(name, onload)
			kproc.spawn(name, function()
				puts('Loading ' .. name .. '...')
				local ret, val = _c_kernel.load('='..name)
				if ret then
					puts('done\n')
					ret = ret()
					if onload then
						onload(ret)
					end
				else
					puts('failed\n' .. tostring(val) .. '\n')
				end
			end)
			while kproc.runproc(name) do
			end
		end

		-- NOTE: Is this appropriate?
		kernel.spawn = kproc.spawn

		puts('Welcome to Khoros\n(c) Matthias Miller\n')

		load_module('keyboard')
		load_module('mouse')

		-- TODO: Genericize.
		kproc.spawn('lance', function()
			puts('Loading lance...')
			local ret, val = _c_kernel.load('=pci')
			local pci = assert(ret, val)()

			ret, val = _c_kernel.load('=lance')
			local lance = assert(ret, val)()
			puts('done\n')

			lance.init(pci)
		end)
		while kproc.runproc('lance') do
		end

		load_module('shell')

		while true do
			while true do
				local alive = kproc.run()
				local interrupt = _c_kernel.interrupt()
				if interrupt == nil and alive == 0 then
					break
				end

				if interrupt ~= nil then
					if interrupt > 0 and interrupt < 10 then
						-- TODO: fix int/string conversion
						local msgname = 'interrupt' .. tostring(interrupt):sub(1,1)
						ipc.broadcast(msgname)
					end
				end
			end

			_c_kernel.idle()
		end
	end
end

