pci = {}
do
	local _PciCONFADD = 3320 --0xcf8
	local _PciCONFDATA = 3324 --0xcfc
	local _PciPM2 = 34 --0x022

	-- PCI registers available through CONFADD/CONFDATA
	local _PciVID = 0		--0x00		vendor id - 16 ro
	local _PciDID = 2		--0x02		device id - 16 ro
	local _PciCMD = 4		--0x04		command - 16 rw
	local _PciSTS = 6		--0x06		status - 16 rwc
	local _PciRID = 8		--0x08		revision id - 8 ro
	local _PciSUBC = 10		--0x0a		subclass code - 8 ro
	local _PciBCC = 11		--0x0b		baseclass code - 8 ro
	local _PciMLT = 13		--0x0d		master latency timer - 8 rw
	local _PciHDR = 14		--0x0e		header type - 8 ro
	local _PciIOBASE = 16	--0x10		IO base - 32 rw
	local _PciMEMBASE = 20	--0x14		Memory base - 32 rw
	local _PciINT = 60		--0x3c		interrupt line - 8 rw
	local _PciPIN = 61		--0x3d		interupt pin - 8

	-- PciCMD bits
	local _PciBME = 4		--bus master enable

	local function CONFADDR(en, bus, dev, func, reg)
		-- Cannot use binary or. Use addition instead.
		return shiftl(en, 31) + shiftl(bus, 16) +
				shiftl(dev, 11) + shiftl(func, 8) + (reg)
	end
	function pci.rw(bus, dev, func, reg, size, wr, val)
		assert(wr == true or wr == false)
		if wr then
			assert(val ~= nil)
		else
			assert(val == nil)
		end

		local _0xFC = 252
		local caddr = CONFADDR(1, bus, dev, func, bit_and(reg, _0xFC))
		local addr = _PciCONFDATA + bit_and(reg, 3)
		kernel.out32(_PciCONFADD, caddr)

		local ret = nil
		if size == 1 then
			if wr then
				kernel.out8(addr, val)
			else
				ret = kernel.in8(addr)
			end
		elseif size == 2 then
			if wr then
				kernel.out16(addr, val)
			else
				ret = kernel.in16(addr)
			end
		elseif size == 4 then
			if wr then
				kernel.out32(addr, val)
			else
				ret = kernel.in32(addr)
			end
		else
			assert(false, 'invalid size')
		end

		if wr then
			assert(ret == nil)
		else
			assert(ret ~= nil)
		end

		kernel.out32(_PciCONFADD, 0)
		return ret
	end
	function pci.read(pci_, reg, size)
		return pci.rw(pci_.bus, pci_.dev, pci_.func, reg, size, false, nil)
	end
	function pci.write(pci_, reg, size, val)
		return pci.rw(pci_.bus, pci_.dev, pci_.func, reg, size, true, val)
	end
	function pci.match(target_vid, target_did)
		assert(target_vid ~= nil)
		assert(target_did ~= nil)
		pcis = {}
		for bus=0,8 do
			for dev=0,32 do
				local vid = pci.rw(bus, dev, 0, _PciVID, 2, false, nil)
				local did = pci.rw(bus, dev, 0, _PciDID, 2, false, nil)
				assert(vid ~= nil)
				assert(did ~= nil)
				if vid == target_vid and did == target_did then
					local _0xfff0 = 65520
					local base = pci.rw(bus, dev, 0, _PciIOBASE, 4, false, nil)
					local pci = {
						bus = bus,
						dev = dev,
						func = 0,
						iobase = bit_and(base, _0xfff0),
						intno = pci.rw(bus, dev, 0, _PciINT, 1, false, nil),
						pin = pci.rw(bus, dev, 0, _PciPIN, 1, false, nil)
					}
					table.insert(pcis, pci)
				end
			end
		end
		return pcis
	end
	function pci.busmaster(pci_, enable)
		assert(enable == true or enable == false)
		local x = pci.read(pci_, _PciCMD, 2)
		assert(x ~= nil)
		if enable then
			x = bit_or(x, _PciBME)
		else
			x = bit_and(x, bit_cmpl(_PciBME))
		end
		assert(x ~= nil)
		pci.write(pci_, _PciCMD, 2, x)
	end
end
return pci

