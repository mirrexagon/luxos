
local _numbits = 16

function floor(num)
	return num - (num % 1)
end

function shiftr(num, bits)
	return floor(num / (2 ^ bits))
end

function shiftl(num, bits)
	return num * (2 ^ bits)
end

-- return single bit (for OR)
local function _bit(x,b)
	return (x % 2^b - x % 2^(b-1) > 0)
end

function bit_or(x,y)
	local result = 0
	for p=1,_numbits do
		result = result + (((_bit(x,p) or _bit(y,p)) == true) and 2^(p-1) or 0)
	end
	return result
end

function bit_and(x,y)
	local result = 0
	for p=1,_numbits do
		result = result + (((_bit(x,p) and _bit(y,p)) == true) and 2^(p-1) or 0)
	end
	return result
end

function bit_cmpl(x)
	local z = 0
	for p=1,_numbits do
		z = z + shiftl(1, p-1)
	end
	return z - bit_and(z, x)
end

function rpad(s, c, width)
	assert(c:len() == 1)
	return s .. c:rep(width - s:len())
end

function rstrip(s, c)
	local new_len = #s
	for i=#s,1 do
		if s:sub(i,i) == c then
			new_len = new_len - 1
		else
			break
		end
	end
	return s:sub(1,new_len), #s - new_len
end

function puts(s)
	ipc.send('tty', 'puts', s)
end

function print(...)
	for i,v in ipairs(arg) do
		if i > 1 then
			puts('\t')
		end
		puts(tostring(v))
	end
	puts('\n')
end

