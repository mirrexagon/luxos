local _0x64 = 100
local _0x60 = 96
local status = kernel.in8(_0x64)

local function send_command(cmd)
	-- Wait for the mouse to become ready.
	while bit_and(kernel.in8(_0x64), 2) ~= 0 do
	end

	local _0xD4 = 212
	kernel.out8(_0x64, _0xD4)
	kernel.out8(_0x64, cmd)
end

local function enable()
	local _0x20 = 32
	send_command(_0x20)
	local status = kernel.in8(_0x60)
	-- Clear bit 5 (enabling interrupts)
	local bit5 = _0x20
	status = bit_and(status, bit_cmpl(bit5))
	-- Enable bit 1
	status = bit_or(status, 1)

	send_command(_0x60)
	kernel.out8(_0x60, status)
end

enable()

