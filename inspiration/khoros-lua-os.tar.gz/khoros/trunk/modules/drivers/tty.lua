
--SCREEN FUNCTIONS
do
	local _cx = 80
	local _cy = 25

	local _blank_line = (' '):rep(_cx)
	local _text = {}
	local _curx = 1
	local _cury = 1
	for i=1,_cy do
		table.insert(_text, _blank_line)
	end

	local function set_cursor (x, y)
		assert(x >= 1 and x <= _cx)
		assert(y >= 1 and y <= _cy)

		local _0x3D4 = 980
		local _0x3D5 = 981

		local pos = (y - 1) * 80 + (x - 1)
		local upper = shiftr(pos, 8)
		local lower = pos % shiftl(1, 8)

		kernel.out8(_0x3D4, 14)
		kernel.out8(_0x3D5, upper)
		kernel.out8(_0x3D4, 15)
		kernel.out8(_0x3D5, lower)
	end

	local function refresh_screen()
		for y=1,_cy do
			kernel.draw(1, y, _text[y])
		end
		set_cursor(_curx, _cury)
	end

	local function split(s, delim, max_len)
		local results = {}
		local start_of_line = 1
		while start_of_line <= s:len() do
			-- Find the new delimiter.
			local delim_pos = s:find(delim, start_of_line)

			local end_of_line, next_line
			if delim_pos ~= nil then
				-- This line ends just before the delimiter.
				-- The next line starts just after it.
				end_of_line = delim_pos - 1
				next_line = delim_pos + delim:len()
			else
				-- No delimiter. Line ends at end of the string.
				end_of_line = s:len()
				next_line = end_of_line + 1
			end

			-- Respect max_len
			if max_len ~= nil then
				if end_of_line > start_of_line + max_len - 1 then
					end_of_line = start_of_line + max_len - 1
					next_line = end_of_line + 1
				end
			end

			table.insert(results, s:sub(start_of_line, end_of_line))
			start_of_line = next_line
		end
		return results
	end

	local function _puts(s)
		while #s > 0 do
			--Find the length of the next line
			local next_line

			local eol = s:find('\n')
			if eol ~= nil then
				next_line = s:sub(1, eol-1)
				s = s:sub(eol+1)
			else
				next_line = s
				s = ''
			end

			repeat
				-- Find the piece that needs to be updated in the line.
				local backspace = next_line:find('\b')
				local insertion
				if backspace ~= nil then
					insertion = next_line:sub(1,backspace-1)
					next_line = next_line:sub(backspace+1)
				else
					insertion = next_line
					next_line = ''
				end

				-- If this is more than will fit on the line, put some back.
				local visible_len =  _cx - _curx + 1
				if visible_len < #insertion then
					next_line = insertion:sub(visible_len + 1) .. next_line
					insertion = insertion:sub(1, visible_len)
				end

				-- Patch in the new insertion
				_text[_cury] = _text[_cury]:sub(1, _curx-1) ..
								insertion ..
								_text[_cury]:sub(_curx + #insertion)
				_curx = _curx + #insertion
				if backspace ~= nil then
					-- This landed us at the beginning of a line. 
					-- Jump up a line if possible.
					if _curx == 1 then
						if _cury > 1 then
							_cury = _cury - 1
							_curx = _cx
						end
					else
						_curx = _curx - 1
					end
				end

				-- Stop if the line is maxed out or
				-- if this is the end of the buffer.
				if _curx > _cx or (#next_line == 0 and eol) then
					_cury = _cury + 1
					_curx = 1

					if _cury > _cy then
						table.remove(_text, 1)
						table.insert(_text, _blank_line)
						_cury = _cury - 1
					end
				end
			until #next_line == 0
		end

		refresh_screen()
	end

	refresh_screen()

	while true do
		local msg = ipc.recv{ name = 'puts' }
		_puts(tostring(msg.value))
	end
end

