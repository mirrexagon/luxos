local pending_keys = nil
local function read_line(prompt)
	assert(pending_keys == nil)
	pending_keys = ''
	puts(prompt)
end

-- TO RUN COMMANDS
local pending_command = ''
local function on_enter(line)
	pending_command = pending_command .. line .. '\n'

	-- Try to evaluate this pending_command
	-- If it's incomplete, read another line.
	func, err = loadstring(pending_command)
	if func == nil and tostring(err):find('<eof>') ~= nil then
		read_line('> ')
		return
	end

	pending_command = ''

	if func ~= nil then
		-- This function yanks the status off pcall's return value.
		local function pcall_results(status, ...)
			return arg
		end
		-- It's valid code. Call the function.
		results = pcall_results(pcall(func))
		if #results > 0 then
			print(unpack(results))
		end
	else
		-- Invalid snippet.
		puts(err .. '\n')
	end

	read_line('$ ')
end

-- TO READ LINES FROM STDIN
local function onkey(key, char)
	if pending_keys == nil then
		return
	end

	if not char then
		-- ignore
	elseif char == '\n' then
		-- Stop reading.
		local enter_parm = pending_keys
		pending_keys = nil
		puts(char)

		on_enter(enter_parm)
	elseif char == '\b' then
		if #pending_keys > 0 then
			puts('\b \b')
			pending_keys = pending_keys:sub(1, #pending_keys-1)
		end
	else
		pending_keys = pending_keys .. char 
		puts(char)
	end
end

-- Show the prompt.
print()
on_enter('')

ipc.subscribe{ from = 'keyboard', name = 'key' }
while true do
	local msg = ipc.recv{ from = 'keyboard', name = 'key' }
	onkey(msg.value[1], msg.value[2])
end

