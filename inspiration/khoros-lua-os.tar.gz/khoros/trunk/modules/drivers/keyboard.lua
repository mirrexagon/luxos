local _scancodes = {
	nil,  27, {'1','!'}, {'2','@'}, {'3','#'}, {'4','$'},
	{'5','%'}, {'6','^'}, {'7','&'}, {'8','*'},	--9
	{'9','('}, {'0',')'}, {'-','_'}, {'=','+'}, '\b',	--Backspace
	'\t',			--Tab
	{'q','Q'}, {'w','W'}, {'e','E'}, {'r','R'},	--19
	{'t','T'}, {'y','Y'}, {'u','U'}, {'i','I'}, {'o','O'},
	{'p','P'}, {'[','{'}, {']','}'}, '\n',		--Enter key
	nil,			--29   - Control
	{'a','A'}, {'s','S'}, {'d','D'}, {'f','F'}, {'g','G'},
	{'h','H'}, {'j','J'}, {'k','K'}, {'l','L'}, {';',':'},	--39
	{'\'','"'}, {'`','~'},   nil,		--Left shift
	{'\\','|'}, {'z','Z'}, {'x','X'}, {'c','C'},
	{'v','V'}, {'b','B'}, {'n','N'},			--49
	{'m','M'}, {',','<'}, {'.','>'}, {'/','?'},   nil,	--Right shift
	'*',
	nil,	--Alt
	' ',	--Space bar
	nil,	--Caps lock
	nil,	--59 - F1 key ... >
	nil,   nil,   nil,   nil,   nil,   nil,   nil,   nil,
	nil,	--< ... F10
	nil,	--69 - Num lock*/
	nil,	--Scroll Lock
	nil,	--Home key
	nil,	--Up Arrow
	nil,	--Page Up
	'-',
	nil,	--Left Arrow
	nil,
	nil,	--Right Arrow
	'+',
	nil,	--79 - End key*/
	nil,	--Down Arrow
	nil,	--Page Down
	nil,	--Insert Key
	nil,	--Delete Key
	nil,   nil,   nil,
	nil,	--F11 Key
	nil,	--F12 Key
	nil,	--All other keys are undefined
}

local caps_lock = 58
local left_shift = 42
local right_shift = 54

local has_caps = false
local has_left_shift = false
local has_right_shift = false

local function keyboard_interrupt()
	local _0x60 = 96
	local key = kernel.in8(_0x60)
	if key == 0 then
		return
	end

	_0x80 = 128
	_0x7F = 127
	local is_up = (bit_and(key, _0x80) ~= 0)
	key = bit_and(key, _0x7F)

	local text = _scancodes[key+1]
	if type(text) == 'table' then
		if has_left_shift or has_right_shift then
			text = text[2]
		else
			text = text[1]
		end
	end

	if key == left_shift then
		has_left_shift = not is_up
	elseif key == right_shift then
		has_right_shift = not is_up
	elseif key == caps_lock then
		has_caps = not has_caps
	elseif type(text) == 'string' then
		if not is_up then
			ipc.broadcast('key', { key, text })
		end
	else
		if not is_up then
			ipc.broadcast('key', { key, nil })
		end
	end
end

-- Read any key in the queue so that interrupts will get fired.
ipc.subscribe{ from = 'kernel', name = 'interrupt1' }
keyboard_interrupt()

while true do
	local msg = ipc.recv{ from = 'kernel', name = 'interrupt1' }
	keyboard_interrupt()
end

