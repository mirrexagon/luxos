lance = {}
do
	local _pcis = nil

	local RLENlog = 3 -- 2^RLEN = number of read buffers in ring
	local TLENlog = 3 -- 2^TLEN = number of write buffers in ring
	local RLEN = shiftl(1, RLENlog)
	local TLEN = shiftl(1, TLENlog)
	local RBSIZE = 2048
	local ETHERMTU = 1500
	assert(RBSIZE >= ETHERMTU + 4)

	_Rdp = 0	-- 0x0	-- register data port - CSRx access through Rap/Rdp
	_Rap = 1	-- 0x1	-- register address port
	_Reset = 2	-- 0x2	-- read to reset
	_Bdp = 3	-- 0x3	-- BCR data port - BCRx access through Rap/Bdp

	local BITS = {
		Init = shiftl(1, 0),
		Strt = shiftl(1, 1),
		Stop = shiftl(1, 2),
		Tdmd = shiftl(1, 3),
		Txon = shiftl(1, 4),
		Rxon = shiftl(1, 5),
		Iena = shiftl(1, 6),
		Intr = shiftl(1, 7),
		Idon = shiftl(1, 8),
		Tint = shiftl(1, 9),
		Rint = shiftl(1, 10),
		Merr = shiftl(1, 11),
		Miss = shiftl(1, 12),
		Cerr = shiftl(1, 13),
		Babl = shiftl(1, 14),
		Err  = shiftl(1, 15)
	}

	local REGISTERS = {
		Csr0 = 0,           -- status register
		IblockAddr = 1,     -- init block address
		Imask = 3,          -- interrupt masks and deferral
		Features = 4,       -- test and features control
		SoftStyle = 58,     -- software style, alias for BCR20
		ChipId = 88,        ---chip id
	}

	local FLAGS1 = {
		Own = shiftl(1, 31),
		RingErr = shiftl(1, 30),
		FrameErr = shiftl(1, 29),
		AddFcs = shiftl(1, 29),		-- set fcs when writing
		OflowErr = shiftl(1, 28),
		CrcErr = shiftl(1, 27),
		BufErr = shiftl(1, 26),
		Start = shiftl(1, 25),
		End = shiftl(1, 24),
	};

	local function NEXTINDEX(i, size)
		-- Assumes 1-based
		return (i % size) + 1
	end

	local function LANCEADDR(base, off, size)
		_0x10 = 16
		return (base) + _0x10 + (off) * (size)
	end

	function lance.read(dev, off, size)
		assert(size == 2 or size == 4)
		if size == 2 then
			return kernel.in16(LANCEADDR(dev.pci.iobase, off, size))
		elseif size == 4 then
			return kernel.in32(LANCEADDR(dev.pci.iobase, off, size))
		end
	end

	function lance.write(dev, off, size, val)
		assert(size == 2 or size == 4)
		assert(val ~= nil)
		if size == 2 then
			return kernel.out16(LANCEADDR(dev.pci.iobase, off, size), val)
		elseif size == 4 then
			return kernel.out32(LANCEADDR(dev.pci.iobase, off, size), val)
		end
	end

	function lance.readcsr(dev, reg, size)
		lance.write(dev, _Rap, 4, reg)
		return lance.read(dev, _Rdp, size)
	end

	function lance.writecsr(dev, reg, size, val)
		lance.write(dev, _Rap, 4, reg)
		lance.write(dev, _Rdp, size, val)
	end

	local function setmem_smallendian(mem, offset, num)
		mem:set(offset+0, bit_and(shiftr(num, 24), 255))
		mem:set(offset+1, bit_and(shiftr(num, 16), 255))
		mem:set(offset+2, bit_and(shiftr(num, 8), 255))
		mem:set(offset+3, bit_and(num, 255))
	end

	local function getmem_smallendian(mem, offset)
		return (
			shiftl(mem:get(offset+3), 24) + 
			shiftl(mem:get(offset+2), 16) +
			shiftl(mem:get(offset+1), 8) +
			shiftl(mem:get(offset+0))
		)
	end

	local function alignednew(size, align)
		local x = kernel.new(size + align-1)
		local align_offset = (align - (x:addr() % align)) % align
		assert((x:addr() + align_offset) % align == 0)
		assert(align_offset + size <= x:size())
		return x, align_offset
	end

	local function newring(dev, count)
		-- addr		- 4 bytes (void*) - buffer address
		-- flags1	- 4 bytes (uint) - flags and the Bcnt field
		-- flags2	- 4 bytes (uint) - Rcc and Rpc fields
		-- reserved	- 4 bytes (void*)
		local RINGDESC_SIZE = 16
		descriptors, align_offset = alignednew(RINGDESC_SIZE * count, 16)

		local rings = {}
		for i=1,count do
			local desc_offset = align_offset + (i-1) * RINGDESC_SIZE + 1

			-- Create the buffer
			local ring_buf = kernel.new(RBSIZE)
			setmem_smallendian(descriptors, desc_offset, ring_buf:addr())

			rings[i] = {
				setflag1 = function(flag)
					setmem_smallendian(ring_buf, desc_offset + 4, flag)
				end,

				setflag2 = function(flag)
					setmem_smallendian(ring_buf, desc_offset + 8, flag)
				end,

				getflag1 = function(flag)
					return getmem_smallendian(ring_buf, desc_offset + 4)
				end,

				getflag2 = function(flag)
					return getmem_smallendian(ring_buf, desc_offset + 8)
				end,

				buf = ring_buf
			}
		end
		return descriptors:addr(), rings
	end

	local function newinitblock(dev, rdescaddr, tdescaddr)
		-- mode - 2 bytes (unsigned short) - mode as in CSR15
		-- rlen - 1 byte - note: upper four bits
		-- tlen - 1 byte - note: upper four bits
		-- padr - 6 bytes - ethernet address
		-- pad1 - 2 bytes
		-- laddr - 8 bytes - logical address filter
		-- rdra - 4 bytes (uint) - xmit/rcv ring descrptors - 16-byte aligned
		-- tdra - 4 bytes (uint)
		x, align_offset = alignednew(28, 16)
		x:set(align_offset + 3, shiftl(RLENlog, 4))
		x:set(align_offset + 4, shiftl(TLENlog, 4))
		for i=1,6 do
			x:set(align_offset + i+4, dev.mac[i])
		end
		setmem_smallendian(x, align_offset + 21, rdescaddr)
		setmem_smallendian(x, align_offset + 25, tdescaddr)
		return x, x:addr() + align_offset
	end

	local function interrupt(dev)
		print('Got interrupt!')
	end

	local function init79c970(dev)
		-- read from the reset port, then write a 32-bit val to
		-- Rdp to put it into 32-bit mode
		lance.read(dev, _Reset, 4)
		lance.read(dev, _Reset, 2)
		lance.write(dev, _Rdp, 4, 0)

		-- verify that it worked
		if lance.readcsr(dev, REGISTERS.Csr0, 4) ~= BITS.Stop then
			assert(false, 'init failed')
		end

		-- check out the chip id
		_0x2420003 = 37879811
		_0x2621003 = 39981059
		local x = lance.readcsr(dev, REGISTERS.ChipId, 4)
		if x == _0x2420003 then
			puts('Found chip 79c970\n')
		elseif x == _0x2621003 then
			puts('Found chip 79c970A\n')
		else
			assert(false, 'unknown chip id')
		end

		-- set up interrupt
		--[[
		for i=2,16 do
			local x = i
			register_interrupt(x, function()
				print('Got interrupt ' .. tostring(x))
			end)
		end
		register_interrupt(dev.pci.intno, function() interrupt(dev) end)
		]]--

		pci.busmaster(dev.pci, true)

		-- software-style 2: 32-bit data structures
		lance.writecsr(dev, REGISTERS.SoftStyle, 4, 2);
		-- turn on auto-pad-transmit feature
		lance.writecsr(dev, REGISTERS.Features, 4,
			bit_or(lance.readcsr(dev, REGISTERS.Features, 4), shiftl(1, 11)))

		dev.mac = {}
		for i=1,6 do
			table.insert(dev.mac, kernel.in8(dev.pci.iobase + i - 1))
		end

		local _0xffff = 65535
		rdescaddr, dev.rring = newring(dev, RLEN)
		tdescaddr, dev.tring = newring(dev, TLEN)
		for i=1,#dev.rring do
			dev.rring[i].setflag1(i,
				bit_or(FLAGS1.Own, bit_and(-RBSIZE, _0xffff)))
		end

		dev.iblock, dev.iblockaddr = newinitblock(dev, rdescaddr, tdescaddr)
		lance.writecsr(dev, REGISTERS.IblockAddr, 4,
						bit_and(dev.iblockaddr, _0xffff))
		lance.writecsr(dev, REGISTERS.IblockAddr+1, 4,
						bit_and(shiftr(dev.iblockaddr, 16), _0xffff))

		-- ignore Idon interrupts, init the chip, wait for it, and then start it
		-- with interupts enabled
		lance.writecsr(dev, REGISTERS.Imask, 4, BITS.Idon)
		lance.writecsr(dev, REGISTERS.Csr0, 4, BITS.Init)
		while bit_and(lance.readcsr(dev, REGISTERS.Csr0, 4), BITS.Idon) == 0 do
		end
		lance.writecsr(dev, REGISTERS.Csr0, 4, bit_or(BITS.Iena, BITS.Strt))

		lance._eth_write(dev)
	end

	function lance.init(pci)
		assert(_pcis == nil)
		local _0x1022 = 4130
		local _0x2000 = 8192
		_pcis = pci.match(_0x1022, _0x2000)
		for i=1,#_pcis do
			local dev = { pci = _pcis[i] }
			init79c970(dev)
			_dev = dev -- TODO
		end
		return #_pcis
	end

	function lance._eth_write(dev, data)
		-- TODO
		dev.tidx = 1
		dev.tpending = 0

		local data
		do
			data = { 255, 255, 255, 255, 255, 255 }
			for i=1,6 do
				table.insert(data, dev.mac[i])
			end
			table.insert(data, 0)
			table.insert(data, 0)
			for i=1,42 do
				table.insert(data, i)
			end
		end

		assert(dev.tpending < TLEN)
		local ring = dev.tring[dev.tidx]
		for i=1,#data do
			ring.buf:set(i,data[i])
		end

		-- Wait to update until buffer has been initialized.
		dev.tidx = NEXTINDEX(dev.tidx, TLEN)
		dev.tpending = dev.tpending + 1

		local _0xffff = 65535
		ring.setflag2(0)
		ring.setflag1(
					bit_or(FLAGS1.Own,
					bit_or(FLAGS1.Start,
					bit_or(FLAGS1.End,
					bit_and(-#data, _0xffff)
		))))
		lance.writecsr(dev, REGISTERS.Csr0, 4, bit_or(BITS.Iena, BITS.Tdmd))
	end

end
return lance

