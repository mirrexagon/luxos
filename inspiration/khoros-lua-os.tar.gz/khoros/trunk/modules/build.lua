-- $Id: $

-- Copyright (c) 2009, Matthias Miller, Jörg Zinke (developers@khoros.org)
-- All rights reserved.
--
-- Redistribution and use in source and binary forms, with or without
-- modification, are permitted provided that the following  conditions
-- are met:
--
--    - Redistributions of source code must retain the above copyright
--      notice, this list of conditions and the following disclaimer.
--    - Redistributions in binary form must reproduce the above
--      copyright notice, this list of conditions and the following
--      disclaimer in the documentation and/or other materials provided
--      with the distribution.
--    - Neither the name of the khoros team nor the names of its
--      contributors may be used to endorse or promote products derived
--      from this software without specific prior written permission.
--
-- THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
-- "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
-- LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
-- FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
-- COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
-- INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
-- BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
-- LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
-- CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
-- LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
-- ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
-- POSSIBILITY OF SUCH DAMAGE.

-- build module

-- todo: - check if compiling is really needed via timestamps or hash

module(..., package.seeall)

require("io")
require("os")
require("string")
require("table")

require("filesystem")
require("path")

-- default environment
function environment()
    local environment = nil

    -- default environment
    environment = {
        temporary = "temporary/build",
        -- assembler language
        asm = os.getenv("ASM") or "tcc",
        asmflags = os.getenv("ASMFLAGS") or "", asmoptions = "-c",
        -- c language
        cc = os.getenv("CC") or "tcc",
        ccflags = os.getenv("CCFLAGS") or "", ccoptions = "-c",
        -- linker
        linker = os.getenv("LD") or "tcc",
        linkerflags = os.getenv("LDFLAGS") or "", linkeroptions = ""
    }

    return environment
end

-- compile
function compile(environment, sources)
    local file = ""
    local extension = ""
    local output = ""
    local objects = {}
    local template = ""
    local command = ""

    assert(type(environment) == "table", "environment is not a table")
    assert(type(environment.temporary) == "string", "environemnt temporary is not a string")
    assert(type(sources) == "table", "sources is not a table")

    -- compile all sources
    for _, source in ipairs(sources) do
        assert(type(source) == "string", "source is not a string")
        assert(string.len(source) > 0, "source length is zero")

        -- set output file
        file, extension = path.extension(source)
        output = environment.temporary .. "/" .. file .. ".o"
        filesystem.create_directory(path.directory(output), true)

        -- todo: check if compiling is needed

        -- language dependent compilation
        if string.lower(extension) == "c" then
            assert(type(environment.cc) == "string", "environment compiler is not a string")
            assert(string.len(environment.cc) > 0, "environment compiler length is zero")
            template = "$cc $ccoptions -o $output $ccflags $source"
        elseif string.lower(extension) == "s" then
            assert(type(environment.asm) == "string", "environment assembler is not a string")
            assert(string.len(environment.asm) > 0, "environment assembler length is zero")
            template = "$asm $asmoptions -o $output $asmflags $source"
        else
            error("compile not implemented for language with extension " .. extension)
        end

        -- compile command
        command = string.gsub(template, "%$(%w+)", environment)
        command = string.gsub(command, "%$output", output)
        command = string.gsub(command, "%$source", source)
        print(command)
        assert(os.execute(command) == 0, "failed to compile source")

        -- keep object file
        table.insert(objects, output)
    end

    return objects
end

-- link
function link(environment, name, objects)
    local output = ""
    local template = ""
    local command = ""

    assert(type(environment) == "table", "environment is not a table")
    assert(type(environment.temporary) == "string", "environemnt temporary is not a string")
    assert(type(name) == "string", "name is not a string")
    assert(string.len(name) > 0, "name length is zero")
    assert(type(objects) == "table", "objects is not a table")

    -- set output file
    output = environment.temporary .. "/" .. name
    filesystem.create_directory(path.directory(output), true)

    -- link object files
    template = "$linker $linkeroptions -o $output $linkerflags $objects"
    command = string.gsub(template, "%$(%w+)", environment)
    command = string.gsub(command, "%$output", output)
    command = string.gsub(command, "%$objects", table.concat(objects, " "))
    print(command)
    assert(os.execute(command) == 0, "failed to link objects")

    return output
end

-- remove temporary files
function remove(environment)
    local directory = ""

    assert(type(environment) == "table", "environment is not a table")
    assert(type(environment.temporary) == "string", "environemnt temporary is not a string")

    -- remove temporary directory
    if filesystem.exist(environment.temporary) then
        print("remove recursive " .. environment.temporary)
        filesystem.remove(environment.temporary, true)
    end
end
