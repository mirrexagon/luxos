-- $Id: $

-- Copyright (c) 2009, Matthias Miller, Jörg Zinke (developers@khoros.org)
-- All rights reserved.
--
-- Redistribution and use in source and binary forms, with or without
-- modification, are permitted provided that the following  conditions
-- are met:
--
--    - Redistributions of source code must retain the above copyright
--      notice, this list of conditions and the following disclaimer.
--    - Redistributions in binary form must reproduce the above
--      copyright notice, this list of conditions and the following
--      disclaimer in the documentation and/or other materials provided
--      with the distribution.
--    - Neither the name of the khoros team nor the names of its
--      contributors may be used to endorse or promote products derived
--      from this software without specific prior written permission.
--
-- THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
-- "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
-- LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
-- FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
-- COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
-- INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
-- BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
-- LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
-- CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
-- LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
-- ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
-- POSSIBILITY OF SUCH DAMAGE.

-- filesystem module

-- todo: - remove lfs dependency and use native khoros functions
--       - implement copy
--       - implement touch

module(..., package.seeall)

require("os")
require("string")

require("lfs")

-- copy file
function copy(source, destination)
    assert(type(source) == "string", "source is not a string")
    assert(string.len(source) > 0, "source length zero")
    assert(type(destination) == "string", "destination is not a string")
    assert(string.len(destination) > 0, "destination length zero")

    assert(exist(source), "source does not exist")
    assert(file(source), "source is not a file")
    assert(exist(destination) == false or file(destination), "destination is not a file")

    -- copy source to destination
    -- todo: quick hack for now
    assert(os.execute("cp " .. source .. " " .. destination) == 0, "failed to copy")
end

-- change directory
function change_directory(path)
    assert(type(path) == "string", "path is not a string")
    assert(string.len(path) > 0, "path length zero")

    -- change directory
    assert(lfs.chdir(path))
end

-- create directory
function create_directory(path, intermediate)
    local current = ""

    assert(type(path) == "string", "path is not a string")
    assert(string.len(path) > 0, "path length zero")
    assert(intermediate == nil or type(intermediate) == "boolean", "intermediate is not a boolean")

    if not intermediate then
        -- create directory
        assert(lfs.mkdir(path))
        return
    end

    -- iterate over path components
    for component in string.gmatch(path .. "/", "(.-)/+") do
        -- create intermediate directory
        current = current .. component .. "/"
        if not exist(current) or not directory(current) then
            assert(lfs.mkdir(current))
        end
    end
end

-- directory
function directory(path)
    local mode = nil
    local result = false

    assert(type(path) == "string", "path is not a string")
    assert(string.len(path) > 0, "path length zero")

    -- check if lfs return file attributes
    mode = assert(lfs.attributes(path, "mode"))
    if mode == "directory" then
        result = true
    end

    return result
end

-- exist
function exist(path)
    local result = false

    assert(type(path) == "string", "path is not a string")
    assert(string.len(path) > 0, "path length zero")

    -- check if lfs return file attributes
    if lfs.attributes(path) ~= nil then
        result = true
    end

    return result
end

-- file
function file(path)
    local mode = nil
    local result = false

    assert(type(path) == "string", "path is not a string")
    assert(string.len(path) > 0, "path length zero")

    -- check if lfs return file attributes
    mode = assert(lfs.attributes(path, "mode"))
    if mode == "file" then
        result = true
    end

    return result
end

-- list directory
function list(path)
    local files = {}

    assert(type(path) == "string", "path is not a string")
    assert(string.len(path) > 0, "path length zero")
    assert(directory(path), "path is not a directory")

    -- iterate over given path
    for file in lfs.dir(path) do
        table.insert(files, file)
    end

    return files
end

-- remove file or directory (recursive)
function remove(path, recursive)
    local files = nil

    assert(type(path) == "string", "path is not a string")
    assert(string.len(path) > 0, "path length zero")
    assert(recursive == nil or type(recursive) == "boolean", "recursive is not a boolean")

    -- remove single file or directory
    if not recursive or file(path) then
        assert(os.remove(path))
        return
    end
    assert(directory(path), "path is not a directory")

    -- iterate recursivly through directory
    files = list(path)
    for _, file in ipairs(files) do
        if file ~= "." and file ~= ".." then
            file = path .. "/" .. file
            if directory(file) then
                remove(file, true)
            else
                assert(os.remove(file))
            end
        end
    end

    -- finally remove directory itself
    assert(os.remove(path))
end

-- working directory
function working_directory()
    return assert(lfs.currentdir())
end
