-- $Id: $

-- Copyright (c) 2009, Matthias Miller, Jörg Zinke (developers@khoros.org)
-- All rights reserved.
--
-- Redistribution and use in source and binary forms, with or without
-- modification, are permitted provided that the following  conditions
-- are met:
--
--    - Redistributions of source code must retain the above copyright
--      notice, this list of conditions and the following disclaimer.
--    - Redistributions in binary form must reproduce the above
--      copyright notice, this list of conditions and the following
--      disclaimer in the documentation and/or other materials provided
--      with the distribution.
--    - Neither the name of the khoros team nor the names of its
--      contributors may be used to endorse or promote products derived
--      from this software without specific prior written permission.
--
-- THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
-- "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
-- LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
-- FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
-- COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
-- INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
-- BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
-- LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
-- CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
-- LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
-- ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
-- POSSIBILITY OF SUCH DAMAGE.

-- chunk module

module(..., package.seeall)

require("io")
require("os")
require("string")
require("table")

require("standard")
require("filesystem")

-- load chunk from file
function load(path, custom)
	local objects = nil
    local chunk = nil

    assert(type(path) == "string", "path is not a string")
    assert(string.len(path) > 0, "path length zero")
    assert(filesystem.file(path), "path is not a file")
	assert(type(custom) == "table", "custom is not a table")

	-- builtin objects for sandboxes
	objects = {
		-- safe builtin functions
		assert = assert, error = error, ipairs = ipairs, next = next,
		pairs = pairs, pcall = pcall, print = print, select = select,
		tonumber = tonumber, tostring = tostring, type = type,
		unpack = unpack, xpcall = xpcall,

		-- safe builtin module functions
		coroutine = {
			create = coroutine.create, resume = coroutine.resume,
			running = coroutine.running, status = coroutine.status,
			wrap = coroutine.wrap, yield = coroutine.yield
		},
		string = {
			byte = string.byte, char = string.char, find = string.find,
			format = string.format, gmatch = string.gmatch,
			gsub = string.gsub, len = string.len, lower = string.lower,
			match = string.match, rep = string.rep,
			reverse = string.reverse, sub = string.sub,
			upper = string.upper
		},
		table = {
			insert = table.insert, maxn = table.maxn,
			remove = table.remove, sort = table.sort
		},
		math = {
			abs = math.abs, acos = math.acos, asin = math.asin,
			atan = math.atan, atan2 = math.atan2, ceil = math.ceil,
			cos = math.cos, cosh = math.cosh, deg = math.deg,
			exp = math.exp, floor = math.floor, fmod = math.fmod,
			frexp = math.frexp, huge = math.huge, ldexp = math.ldexp,
			log = math.log, log10 = math.log10, max = math.max,
			min = math.min, modf = math.modf, pi = math.pi,
			pow = math.pow, rad = math.rad, sin = math.sin,
			sinh = math.sinh, sqrt = math.sqrt, tan = math.tan,
			tanh = math.tanh
		},
		os = {
			clock = os.clock, difftime = os.difftime, time = os.time
		}
	}

	-- copy further custom and probably unsafe objects
	if custom then
		table.copy(custom, objects)
	end

    -- load chunk from file
    chunk = assert(loadfile(path))

    -- restrict execution environment of chunk to objects
    setfenv(chunk, objects)

    -- execute chunk
    chunk()

    return objects
end
