-- markup parser

-- allows the implementation of the following callback functions:

-- headline(line)
-- character(char)

-- hash of characters to encode

require("string")

-- encode html entities
local function entities(character)
    local entities = nil
    local entity = nil
    local code = nil

    -- html entities
    entities = {
        ["\""] = "&quot;",
	["&"] = "&amp;",
	["'"] = "&apos;",
	["<"] = "&lt;",
	[">"] = "&gt;"
    }

    -- encode character
    entity = entities[character]
    if not entity then
        code = string.byte(character)
	if code > 127 then
	    entity = string.format("&#%d;", code)
	end
    end

    return entity
end

-- convert markup text to html
function html(text)

    assert(type(text) == "string", "text is not a string")
    assert(string.len(text) > 0, "text length is zero")

    -- html entities
    text = string.gsub(text, "(.)", entities)

    -- reference
    --[""] = "<a href=\"%1\">%1</a>"

    -- italic
    text = string.gsub(text, "/(.-)/", "<i>%1</i>")

    -- headlines
    text = string.gsub(text, "([^\n]+)\n=+", "<h1>%1</h1>")

    -- sections
    text = string.gsub(text, "([^\n]+)\n%-+", "<h2>%1</h2>")

    -- subsections
    text = string.gsub(text, "([^\n]+)\n~+", "<h3>%1</h3>")

    -- separator ----
    text = string.gsub(text, "(%-%-%-%-)", "<hr />")

    -- unchanged
    --[""] = "<pre>%1</pre>",
    -- indention
    --[""] = "<code>%1</code>",
    -- enumeration
    --[""] = "<ol>%1</ol>",
    -- list
    --[""] = "<ul>%1</ul>",

    -- item
    --text = string.gsub(text, "^%s%*%s(.*)", "<li>%1</li>")

    -- *bold*
    text = string.gsub(text, "%*(.-)%*", "<b>%1</b>")

    -- _underline_
    text = string.gsub(text, "_(.-)_", "<u>%1</u>")

    -- -strike-
    text = string.gsub(text, "-(.-)-", "<strike>%1</strike>")

    -- `monospace`
    text = string.gsub(text, "`(.-)`", "<tt>%1</tt>")

    -- paragraph
    --text = string.gsub(text, "(\n\n)(.-)(\n\n)", "%1<p>%2</p>%3")

    return text
end

-- testing -------------------------------------------------------------

testtext = [[
headline
========

paragraph text starts here & "here"
paragraph text starts here & "here"

paragraph text starts here & "here"
paragraph text starts here & "here"
paragraph text starts here & "here"

subsection
----------

-foo- *bar* /foo bar/

paragraph text starts here & "here"
paragraph _text starts_ here & "here"
paragraph `text starts` here & "here"

 * item 1
 * item 2

subsubsection
~~~~~~~~~~~~~

paragraph text starts here & "here"
paragraph text starts here & "here"
paragraph text starts here & "here"

	    ----

paragraph text starts here & "here"
paragraph text starts here & "here"
paragraph text starts here & "here"
]]

print(html(testtext))
