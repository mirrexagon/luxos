/* $Id: $ */

/*
 * Copyright (c) 2009, Matthias Miller, Jörg Zinke (developers@khoros.org)
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following  conditions
 * are met:
 *
 *    - Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *    - Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials provided
 *      with the distribution.
 *    - Neither the name of the khoros team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/*
 * todo: - add support for %p modifier
 *       - add support to itoa for unsigned and (unsigned) long
 */

#include "video.h"

#include "library/stddef.h"
#include "library/printf.h"

/*
 * unisgned integer has 10 digits at most
 * 64 bit unsigned long has 20 digits at most
 */
#define DIGITS (20 + 1)

static void     itoa(int, int, char *, size_t number_size);

/*
 * integer to ascii
 * considered to be simple but not very fast
 */
static void
itoa(int value, int radix, char *number, size_t number_size)
{
	size_t          index;
	int             distance;

	/* set index */
	index = number_size;

	/* check if signed negative decimal is given */
	if (value < 0 && radix == 10) {
		*number++ = '-';
		value = -value;
	}
	/* iterate through digits */
	while (value > 0) {
		/* backwards */
		index--;
		/* set character */
		number[index] = '0' + (value % radix);
		if (number[index] > '9') {
			number[index] = number[index] - ':' + 'a';
		}
		/* next digit */
		value = value / radix;
	}

	/* move everything to the beginning of number array */
	distance = index;
	while (index < number_size) {
		number[(index - distance)] = number[index];
		index++;
	}

	/* terminate number */
	number[(index - distance)] = '\0';

	return;
}

/*
 * printf implementation supporting only a subset of modifiers
 */
int
printf(const char *format,...)
{
	const char    **arguments;
	char            character[] = "?";
	char            number[DIGITS];
	const char     *output;
	int             count = 0;

	/* set arguments */
	arguments = &format + 1;

	/* iterate over given format */
	while (*format != '\0') {
		output = NULL;
		/* check if modifier is given */
		if (*format == '%') {
			*format++;
			switch (*format) {
			case 'd':
			case 'i':
				itoa(*((int *) arguments++), 10, number, sizeof(number));
				output = number;
				break;
			case 'u':
				/* todo */
				itoa(*((int *) arguments++), 10, number, sizeof(number));
				output = number;
				break;
			case 'o':
				itoa(*((int *) arguments++), 8, number, sizeof(number));
				output = number;
				break;
			case 'x':
			case 'X':
				itoa(*((int *) arguments++), 16, number, sizeof(number));
				output = number;
				break;
			case 's':
				output = *arguments++;
				if (output == NULL) {
					output = "(null)";
				}
				break;
			case '%':
				output = "%";
				break;
			case 'c':
				character[0] = *((int *) arguments++);
				output = character;
				break;
			case 'p':
				/* todo */
			default:
				output = "%";
				*format--;
			}
		} else {
			/*
                         * no modifier given set output to current
                         * format character
                         */
			character[0] = *format;
			output = character;
		}

		/* print the output */
		while (*output != '\0') {
			video_character(*output);
			count++;
			output++;
		}

		/* next character */
		*format++;
	}

	return count;
}
