/* $Id: $ */

/*
 * Copyright (c) 2009, Matthias Miller, Jörg Zinke (developers@khoros.org)
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following  conditions
 * are met:
 *
 *    - Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *    - Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials provided
 *      with the distribution.
 *    - Neither the name of the khoros team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include "multiboot.h"
#include "kernel.h"

#include "library/printf.h"

#include "x86/segment.h"
#include "x86/interrupt.h"
#include "x86/exception.h"
#include "x86/request.h"
#include "x86/x86.h"

/* number of interrupts */
#define INTERRUPT_SIZE 256

/* number of cpu exceptions */
#define INTERRUPT_EXCEPTIONS 32

/* number of pic requests */
#define INTERRUPT_REQUESTS 16

/* end of interrupt */
#define INTERRUPT_EOI 0x20

/* interrupt gate types */
enum interrupt_gates {
	INTERRUPT_GATE_32BIT = 0x0e
};

/* interrupt controller ports */
enum interrupt_ports {
	INTERRUPT_PORT_MASTER_COMMAND = 0x20, INTERRUPT_PORT_MASTER_DATA,
	INTERRUPT_PORT_SLAVE_COMMAND = 0xa0, INTERRUPT_PORT_SLAVE_DATA
};

/* interrupt controller initialization command words */
enum interrupt_icws {
	INTERRUPT_ICW_1_INITIALIZE = (0x10 + 0x01),
	INTERRUPT_ICW_2_MASTER = INTERRUPT_EXCEPTIONS,
	INTERRUPT_ICW_2_SLAVE = (INTERRUPT_EXCEPTIONS + (INTERRUPT_REQUESTS / 2)),
	INTERRUPT_ICW_3_MASTER = 0x04,
	INTERRUPT_ICW_3_SLAVE = 0x02,
	INTERRUPT_ICW_4_X86 = 0x01
};

/* interrupt item */
struct interrupt_item {
	unsigned short base_low;
	struct segment_selector selector;
	unsigned int   reserved:5;
	unsigned int   always_zero:3;
	unsigned int   gate_type:4;
	unsigned int   descriptor_type:1;
	unsigned int   privilege:2;
	unsigned int   present:1;
	unsigned short base_high;
}               __attribute__((packed));

static void     interrupt_set(unsigned char, unsigned long);
static void     interrupt_remap(void);

/*
 * interrupts in interrupt descriptor table
 * required static before memory initialization
 */
static struct interrupt_item interrupts[INTERRUPT_SIZE];

/* interrupt exception and request messages */
static const char *interrupt_messages[] = {
	/* exceptions */
	"division by zero", "debug", "non maskable interrupt",
	"breakpoint", "into detected overflow", "out of bounds",
	"invalid opcode", "coprocessor not available",

	"double fault", "coprocessor segment overrun", "bad TSS",
	"segment not present", "stack fault",
	"general protection fault", "page fault", "reserved",

	"floating point", "alignment check", "machine check",
	"reserved", "reserved", "reserved", "reserved", "reserved",

	"reserved", "reserved", "reserved", "reserved", "reserved",
	"reserved", "reserved", "reserved"

	/* requests */
	"system timer", "keyboard", "cascaded signal", "serial port 2 or 4",
	"serial port 1 or 3", "LPT port 2 or sound card",
	"floppy disk controller", "LPT port 1 or sound card",

	"real time clock", "SCSI", "NIC", "NIC", "PS/2 connector mouse",
	"math co-processor or FPU or inter-processor", "primary ATA",
	"secondary ATA"
};

/*
 * set interrupt item in interrupt descriptor table
 */
static void
interrupt_set(unsigned char count, unsigned long base)
{
	/* set interrupt base address */
	interrupts[count].base_low = base & 0xffff;
	interrupts[count].base_high = (base >> 16) & 0xffff;

	/* set segment selector to gdt kernel code */
	interrupts[count].selector.request_privilege = SEGMENT_PRIVILEGE_KERNEL;
	interrupts[count].selector.table_indicator = SEGMENT_TABLE_GDT;
	interrupts[count].selector.index = SEGMENT_ITEM_KERNEL_CODE;

	/* reserved bits are required to be zero */

	/* set gate type to 32 bit interrupt gate */
	interrupts[count].gate_type = INTERRUPT_GATE_32BIT;

	/* descriptor type is not a system segment */

	/* set descriptor privilege */
	interrupts[count].privilege = SEGMENT_PRIVILEGE_KERNEL;

	/* set descriptor present bit */
	interrupts[count].present = 1;

	return;
}

/*
 * remap default master and slave pic irqs from 0-15 to 32-47 to avoid
 * conflicts with cpu exceptions
 */
static void
interrupt_remap(void)
{
	unsigned char   master_mask;
	unsigned char   slave_mask;

	/* save masks */
	master_mask = in(INTERRUPT_PORT_MASTER_DATA);
	slave_mask = in(INTERRUPT_PORT_SLAVE_DATA);

	/*
 	 * pic initialization command word
 	 * set cascaded environment with icw4
 	 */
	out(INTERRUPT_PORT_MASTER_COMMAND, INTERRUPT_ICW_1_INITIALIZE);
	out(INTERRUPT_PORT_SLAVE_COMMAND, INTERRUPT_ICW_1_INITIALIZE);

	/*
	 * pic remapping starting at irq 0
	 * master irqs 0-7 mapped to interrupts 32-39
	 * slave irqs 8-15 mapped to interrupts 40-47
	 */
	out(INTERRUPT_PORT_MASTER_DATA, INTERRUPT_ICW_2_MASTER);
	out(INTERRUPT_PORT_SLAVE_DATA, INTERRUPT_ICW_2_SLAVE);

	/* pic cascade interrupts slave cascaded on irq 2 */
	out(INTERRUPT_PORT_MASTER_DATA, INTERRUPT_ICW_3_MASTER);
	out(INTERRUPT_PORT_SLAVE_DATA, INTERRUPT_ICW_3_SLAVE);

	/* x86 mode with normal eio */
	out(INTERRUPT_PORT_MASTER_DATA, INTERRUPT_ICW_4_X86);
	out(INTERRUPT_PORT_SLAVE_DATA, INTERRUPT_ICW_4_X86);

	/* restore saved mask */
	out(INTERRUPT_PORT_MASTER_DATA, master_mask);
	out(INTERRUPT_PORT_SLAVE_DATA, slave_mask);

	return;
}

/*
 * initialize interrupts
 */
void
interrupt_initialize(void)
{
	struct interrupt_data idt;

	/* set interrupt descriptor table base address and limit */
	idt.limit = sizeof(interrupts) - 1;
	idt.base = (struct interrupt_item *) &interrupts;

	/* set interrupt exception routines */
	interrupt_set(0, (unsigned long) exception_0);
	interrupt_set(1, (unsigned long) exception_1);
	interrupt_set(2, (unsigned long) exception_2);
	interrupt_set(3, (unsigned long) exception_3);
	interrupt_set(4, (unsigned long) exception_4);
	interrupt_set(5, (unsigned long) exception_5);
	interrupt_set(6, (unsigned long) exception_6);
	interrupt_set(7, (unsigned long) exception_7);

	interrupt_set(8, (unsigned long) exception_8);
	interrupt_set(9, (unsigned long) exception_9);
	interrupt_set(10, (unsigned long) exception_10);
	interrupt_set(11, (unsigned long) exception_11);
	interrupt_set(12, (unsigned long) exception_12);
	interrupt_set(13, (unsigned long) exception_13);
	interrupt_set(14, (unsigned long) exception_14);
	interrupt_set(15, (unsigned long) exception_15);

	interrupt_set(16, (unsigned long) exception_16);
	interrupt_set(17, (unsigned long) exception_17);
	interrupt_set(18, (unsigned long) exception_18);
	interrupt_set(19, (unsigned long) exception_19);
	interrupt_set(20, (unsigned long) exception_20);
	interrupt_set(21, (unsigned long) exception_21);
	interrupt_set(22, (unsigned long) exception_22);
	interrupt_set(23, (unsigned long) exception_23);

	interrupt_set(24, (unsigned long) exception_24);
	interrupt_set(25, (unsigned long) exception_25);
	interrupt_set(26, (unsigned long) exception_26);
	interrupt_set(27, (unsigned long) exception_27);
	interrupt_set(28, (unsigned long) exception_28);
	interrupt_set(29, (unsigned long) exception_29);
	interrupt_set(30, (unsigned long) exception_30);
	interrupt_set(31, (unsigned long) exception_31);

	/* remap interrupt controller */
	interrupt_remap();

	/* set interrupt request routines */
	interrupt_set(32, (unsigned long) request_0);
	interrupt_set(33, (unsigned long) request_1);
	interrupt_set(34, (unsigned long) request_2);
	interrupt_set(35, (unsigned long) request_3);
	interrupt_set(36, (unsigned long) request_4);
	interrupt_set(37, (unsigned long) request_5);
	interrupt_set(38, (unsigned long) request_6);
	interrupt_set(39, (unsigned long) request_7);

	interrupt_set(40, (unsigned long) request_8);
	interrupt_set(41, (unsigned long) request_9);
	interrupt_set(42, (unsigned long) request_10);
	interrupt_set(43, (unsigned long) request_11);
	interrupt_set(44, (unsigned long) request_12);
	interrupt_set(45, (unsigned long) request_13);
	interrupt_set(46, (unsigned long) request_14);
	interrupt_set(47, (unsigned long) request_15);

	/* load new interrupt descriptor table */
	lidt(&idt);

	return;
}

/*
 * interrupt exception handler
 * handles interrupt exceptions from cpu
 */
void
interrupt_exception(struct interrupt_register * registers)
{
	unsigned char   interrupt_number;

	/* cut and check sign extended interrupt number */
	interrupt_number = registers->interrupt_number & 0xff;
	if (interrupt_number >= INTERRUPT_EXCEPTIONS) {
		printf("unhandled exception: unexpected interrupt number %d\n", interrupt_number);
		kernel_panic(__FILE__, __LINE__);
		return;
	}

	/* call custom functions for exceptions */
	switch(interrupt_number) {
	default:
		printf("unhandled interrupt exception: %s\n", interrupt_messages[interrupt_number]);
		kernel_panic(__FILE__, __LINE__);
		return;
	}

	return;
}

/*
 * interrupt request handler
 * handles interrupt requests from pic
 */
void
interrupt_request(struct interrupt_register * registers)
{
	unsigned char   interrupt_number;

	/* cut and check sign extended interrupt number */
	interrupt_number = registers->interrupt_number & 0xff;
	if (interrupt_number < INTERRUPT_EXCEPTIONS || interrupt_number >= (INTERRUPT_EXCEPTIONS + INTERRUPT_REQUESTS)) {
		printf("unhandled request: unexpected interrupt number %d\n", interrupt_number);
		kernel_panic(__FILE__, __LINE__);
		return;
	}

	/* call custom functions for request */
	switch(interrupt_number) {
	case 32: /* INTERRUPT_REQUEST_KEYBOARD: */
		/* ignore keyboard interrupt for now */
		break;
	case 33: /* INTERRUPT_REQUEST_CASCADED: */
		/* ignore cascaded interrupts */
		break;
	default:
		printf("unhandled interrupt request: %s\n", interrupt_messages[interrupt_number]);
		kernel_panic(__FILE__, __LINE__);
		return;
	}

	/*
	 * pic interrupt requests require sending an end of
	 * interrupt when finished to the master and if issued
	 * by slave then to the slave too
	 */
	if (registers->interrupt_number >= (INTERRUPT_EXCEPTIONS + (INTERRUPT_REQUESTS / 2))) {
		/*
 		 * the interrupt was greater than 40 send an eoi to
	 	 * the slave controller too
		 */
		out(INTERRUPT_PORT_SLAVE_COMMAND, INTERRUPT_EOI);
	}
	/* always send an eoi to the master controller */
	out(INTERRUPT_PORT_MASTER_COMMAND, INTERRUPT_EOI);

	return;
}
