/* $Id: $ */

/*
 * Copyright (c) 2009, Matthias Miller, Jörg Zinke (developers@khoros.org)
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following  conditions
 * are met:
 *
 *    - Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *    - Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials provided
 *      with the distribution.
 *    - Neither the name of the khoros team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include "multiboot.h"
#include "kernel.h"

#include "library/printf.h"

#include "x86/segment.h"
#include "x86/interrupt.h"
#include "x86/x86.h"

/* segment types */
enum segment_types {
	SEGMENT_TYPE_CODE = 0x0a, SEGMENT_TYPE_DATA = 0x02
};

/* segment item */
struct segment_item {
	unsigned short limit_low;
	unsigned short base_low;
	unsigned char  base_middle;
	unsigned int   segment_type:4;
	unsigned int   descriptor_type:1;
	unsigned int   privilege:2;
	unsigned int   present:1;
	unsigned int   limit_high:4;
	unsigned int   available:1;
	unsigned int   reserved:1;
	unsigned int   operand_size:1;
	unsigned int   granularity:1;
	unsigned char base_high;
}               __attribute__((packed));

static void     segment_set(unsigned char, enum segment_types, enum segment_privileges);

/*
 * segments in global descriptor table
 * required static before memory initialization
 */
static struct segment_item segments[SEGMENT_ITEM_SIZE];

/*
 * set segment item in global descriptor table
 * all given segments starting at zero and are limited to 4 gbytes
 */
static void
segment_set(unsigned char count, enum segment_types type, enum segment_privileges privilege)
{
	if (count < SEGMENT_ITEM_KERNEL_CODE || count >= SEGMENT_ITEM_SIZE) {
		printf("invalid segment count given %d", count);
		kernel_panic(__FILE__, __LINE__);
		return;
	}
	/* set the segment base address to zero */
	segments[count].base_low = 0;
	segments[count].base_middle = 0;
	segments[count].base_high = 0;

	/* set the segment limit to 4 gbytes */
	segments[count].limit_low = 0xffff;
	segments[count].limit_high = 0x0f;

	/* set segment type to code or data segment */
	segments[count].segment_type = type;

	/* set descriptor type bit to code or data segment */
	segments[count].descriptor_type = 1;

	/* set segment privilege level */
	segments[count].privilege = privilege;

	/* set segment present bit */
	segments[count].present = 1;

	/* available and reserverd bits are required to be zero */

	/* set 32 bit operand size and 4 kbyte granularity */
	segments[count].operand_size = 1;
	segments[count].granularity = 1;

	return;
}

/*
 * initialze segments
 * code segments allow read and execution
 * data segments allow read and write
 */
void
segment_initialize(void)
{
	struct segment_data gdt;

	/* set global descriptor table segments base address and limit */
	gdt.limit = sizeof(segments) - 1;
	gdt.base = (struct segment_item *) &segments;

	/* start with the required null segment */

	/* kernel code segment */
	segment_set(SEGMENT_ITEM_KERNEL_CODE, SEGMENT_TYPE_CODE, SEGMENT_PRIVILEGE_KERNEL);

	/* kernel data segment */
	segment_set(SEGMENT_ITEM_KERNEL_DATA, SEGMENT_TYPE_DATA, SEGMENT_PRIVILEGE_KERNEL);

	/* user code segment */
	segment_set(SEGMENT_ITEM_USER_CODE, SEGMENT_TYPE_CODE, SEGMENT_PRIVILEGE_USER);

	/* user data segment */
	segment_set(SEGMENT_ITEM_USER_DATA, SEGMENT_TYPE_DATA, SEGMENT_PRIVILEGE_USER);

	/* load new global descriptor table */
	lgdt(&gdt);

	return;
}
