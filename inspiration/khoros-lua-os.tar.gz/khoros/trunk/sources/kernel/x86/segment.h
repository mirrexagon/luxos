/* $Id: $ */

/*
 * Copyright (c) 2009, Matthias Miller, Jörg Zinke (developers@khoros.org)
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following  conditions
 * are met:
 *
 *    - Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *    - Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials provided
 *      with the distribution.
 *    - Neither the name of the khoros team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* segment privilege levels */
enum segment_privileges {
	SEGMENT_PRIVILEGE_KERNEL, SEGMENT_PRIVILEGE_USER = 3
};

/* segment tables */
enum segment_tables {
	SEGMENT_TABLE_GDT, SEGMENT_TABLE_LDT
};

/*
 * gdt segment items
 * five segments are required for basic flat model
 */
enum segment_items {
	SEGMENT_ITEM_ZERO, SEGMENT_ITEM_KERNEL_CODE,
	SEGMENT_ITEM_KERNEL_DATA, SEGMENT_ITEM_USER_CODE,
	SEGMENT_ITEM_USER_DATA, SEGMENT_ITEM_SIZE
};

/* segment selector */
struct segment_selector {
	unsigned int   request_privilege:2;
	unsigned int   table_indicator:1;
	unsigned int   index:13;
}               __attribute__((packed));

/* segment data */
struct segment_data {
	unsigned short limit;
	struct segment_item *base;
}               __attribute__((packed));

void            segment_initialize(void);
