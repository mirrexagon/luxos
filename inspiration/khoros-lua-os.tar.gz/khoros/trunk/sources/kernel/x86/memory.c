/* $Id: $ */

/*
 * Copyright (c) 2010, Matthias Miller, Jörg Zinke (developers@khoros.org)
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following  conditions
 * are met:
 *
 *    - Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *    - Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials provided
 *      with the distribution.
 *    - Neither the name of the khoros team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/*
 * physical memory layout
 * 
 * |---------------| memory_size
 * |               |
 * |     heap      | 
 * |               |
 * |---------------+ page_end
 * |     page      | 
 * |---------------+ page_start
 * | memory bitmap |
 * |---------------+ kernel_end
 * |    kernel     |
 * |---------------+ kernel_start 1 MB
 * | lower memory  |
 * '---------------' 0
 * 
 * todo: - use the bios function int 15h, eax=0xe820 to get a reliable 
 *         map of upper memory
 */

#include "multiboot.h"
#include "kernel.h"

#include "library/stddef.h"
#include "library/memset.h"
#include "library/printf.h"

#include "x86/memory.h"

/* memory is reserverd or available */
enum memory_status {
    MEMORY_RESERVED, MEMORY_AVAILABLE
};

/* memory bitamp */
struct memory_bitmap {
    unsigned int *bitmap;
    unsigned int  bitmap_count;
    unsigned int  bitmap_size;
};

static void    memory_set(unsigned long *, enum memory_status);

/* physical memory bitmap */
static struct memory_bitmap memory;

/* address of kernel set in kernel.ld */
extern const void kernel_start;
extern const void kernel_end;

/*
 * set physical memory address
 */
static void
memory_set(unsigned long *address, enum memory_status status)
{

    return;
}

/*
 * allocate physical memory
 */
void *
memory_allocate(size_t size)
{

    return NULL;
}

/*
 * free physical memory
 */
void
memory_free(void *address)
{
    return;
}

/*
 * initialize available memory
 */
void
memory_initialize(unsigned int memory_upper)
{
    unsigned int memory_size;
    
    /* set available memory size */
    memory_size = &kernel_start + memory_upper * 1024;
    
    /* initialize bitmap */
    memory.bitmap = &kernel_end;
    memory.bitmap_count = 0;
    memory.bitmap_size = (unsigned int)(memory_size / MEMORY_PAGE_SIZE / sizeof(unsigned int)); 

    /* initialize all available physical memory */
    /*memset(memory.bitmap, MEMORY_AVAILABLE, memory.bitmap_size);*/

    /*
     * set lower bios memory reserved 
     *
     * ignore all memory below 1 MB for simplicity for now
     * no need to take care of memory map from boot loader
     */
    /*memset(context->memory, MEMORY_RESERVED, context->kernel_start);*/
    
    /* set kernel memory reserved */
    /*memset(context->kernel_start, MEMORY_RESERVED, context->kernel_end);*/

	/* set memory bitmap and page table area reserved */

    return;
}
