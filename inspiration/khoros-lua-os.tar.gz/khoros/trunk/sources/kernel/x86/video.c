/* $Id: $ */

/*
 * Copyright (c) 2009, Matthias Miller, Jörg Zinke (developers@khoros.org)
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following  conditions
 * are met:
 *
 *    - Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *    - Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials provided
 *      with the distribution.
 *    - Neither the name of the khoros team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include "video.h"

#include "x86/segment.h"
#include "x86/interrupt.h"
#include "x86/x86.h"

/* video ram address */
#define VIDEO_ADDRESS 0xb8000

/* number of columns */
#define VIDEO_COLUMNS 80

/* number of lines */
#define VIDEO_LINES 25

/* tabulator width */
#define VIDEO_TABULATOR_WIDTH 8

/* video ram size */
#define VIDEO_RAM_SIZE (VIDEO_COLUMNS * VIDEO_LINES * 2)

/* video crt controller ports */
enum video_ports {
	VIDEO_PORT_INDEX = 0x3d4, VIDEO_PORT_DATA
};

/* video crt controller register */
enum video_register {
	VIDEO_REGISTER_CURSOR_HIGH = 0x0e, VIDEO_REGISTER_CURSOR_LOW
};

/* video colors */
enum video_colors {
	VIDEO_COLOR_BLACK, VIDEO_COLOR_BLUE, VIDEO_COLOR_GREEN,
	VIDEO_COLOR_CYAN, VIDEO_COLOR_RED, VIDEO_COLOR_MAGENTA,
	VIDEO_COLOR_BROWN, VIDEO_COLOR_LIGHT_GRAY, VIDEO_COLOR_DARK_GRAY,
	VIDEO_COLOR_LIGHT_BLUE, VIDEO_COLOR_LIGHT_GREEN,
	VIDEO_COLOR_LIGHT_CYAN, VIDEO_COLOR_LIGHT_RED,
	VIDEO_COLOR_LIGHT_MAGENTA, VIDEO_COLOR_LIGHT_BROWN,
	VIDEO_COLOR_WHITE
};

/* video attribute contains background color and foreground color */
#define VIDEO_ATTRIBUTE ((VIDEO_COLOR_BLACK << 4) | VIDEO_COLOR_GREEN)

/*
 * get video cursor
 */
static void
video_get(unsigned char *column, unsigned char *line)
{
	unsigned short  position;

	/*
         * send command to cursor location high and low register
         * in the crt control register of the vga controller
         * to get cursor
         */
	out(VIDEO_PORT_INDEX, VIDEO_REGISTER_CURSOR_HIGH);
	position = in(VIDEO_PORT_DATA);
	position <<= 8;
	out(VIDEO_PORT_INDEX, VIDEO_REGISTER_CURSOR_LOW);
	position = position + in(VIDEO_PORT_DATA);

	/* set column and line from position */
	*column = position % 80;
	*line = position / 80;

	return;
}

/*
 * set video cursor
 */
static void
video_set(unsigned char column, unsigned char line)
{
	unsigned short  position;

	/* set position */
	position = line * VIDEO_COLUMNS + column;

	/*
         * send command to cursor location high and low register
         * in the crt control register of the vga controller
         * to set cursor
         */
	out(VIDEO_PORT_INDEX, VIDEO_REGISTER_CURSOR_HIGH);
	out(VIDEO_PORT_DATA, (position & 0xff00) >> 8);
	out(VIDEO_PORT_INDEX, VIDEO_REGISTER_CURSOR_LOW);
	out(VIDEO_PORT_DATA, (position & 0x00ff) >> 0);

	return;
}

/*
 * scroll video
 */
static void
video_scroll(void)
{
	volatile unsigned char *video;
	unsigned short  last_line;
	unsigned short  i;

	/* set video ram */
	video = (unsigned char *) VIDEO_ADDRESS;

	/* set last line */
	last_line = (VIDEO_LINES - 1) * (VIDEO_COLUMNS * 2);

	/* iterate over video ram */
	for (i = 0; i < VIDEO_RAM_SIZE; i = i + 2) {
		/*
                 * copy the next line contents to the previous
                 * line along with the attribute byte
                 */
		video[i] = video[i + (VIDEO_COLUMNS * 2)];
		video[i + 1] = video[i + (VIDEO_COLUMNS * 2) + 1];
	}


	/* clear last line */
	for (i = last_line; i < VIDEO_RAM_SIZE; i = i + 2) {
		video[i] = ' ';
		video[i + 1] = VIDEO_ATTRIBUTE;
	}

	return;
}

/*
 * print single character with color attribute
 * supporting a subset of escape sequences
 */
void
video_character(unsigned char character)
{
	volatile unsigned char *video;
	unsigned char column;
	unsigned char line;

	/* set video ram */
	video = (unsigned char *) VIDEO_ADDRESS;

	/* get column and line from cursor */
	video_get(&column, &line);

	switch (character) {
	case '\b':
		if (column > 0) {
			column--;
		}
		break;
	case '\r':
		column = 0;
		break;
	case '\n':
		column = 0;
		line++;
		break;
	case '\t':
		column = column + VIDEO_TABULATOR_WIDTH - (column % VIDEO_TABULATOR_WIDTH);
		break;
	default:
		video[(column + line * VIDEO_COLUMNS) * 2] = character;
		video[(column + line * VIDEO_COLUMNS) * 2 + 1] = VIDEO_ATTRIBUTE;
		column++;
		break;
	}

	/* check if column limit is reached */
	if (column >= VIDEO_COLUMNS) {
		column = column - VIDEO_COLUMNS;
		line++;
	}
	/* check if line limit is reached */
	if (line >= VIDEO_LINES) {
		video_scroll();
		line--;
	}
	/* set cursor to column and line */
	video_set(column, line);

	return;
}

/*
 * clear video
 */
void
video_clear(void)
{
	volatile unsigned char *video;
	unsigned short  i;

	/* set video ram */
	video = (unsigned char *) VIDEO_ADDRESS;

	/* iterate over video ram */
	for (i = 0; i < VIDEO_RAM_SIZE; i = i + 2) {
		video[i] = ' ';
		video[i + 1] = VIDEO_ATTRIBUTE;
	}

	/* set cursor to screen origin */
	video_set(0, 0);

	return;
}
