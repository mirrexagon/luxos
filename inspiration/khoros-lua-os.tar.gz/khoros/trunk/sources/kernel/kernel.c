/* $Id: $ */

/*
 * Copyright (c) 2009, Matthias Miller, Jörg Zinke (developers@khoros.org)
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following  conditions
 * are met:
 *
 *    - Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *    - Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials provided
 *      with the distribution.
 *    - Neither the name of the khoros team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include "multiboot.h"
#include "kernel.h"
#include "video.h"

#include "architecture.h"

#include "library/stddef.h"
#include "library/memset.h"
#include "library/printf.h"

/* copyright year */
#define KERNEL_COPYRIGHT_YEAR "2007-2009"

/* version */
#define KERNEL_VERSION "0.1"

/*
 * kernel panic
 */
void
kernel_panic(const char *filename, unsigned long line_number)
{
	printf("kernel panic in %s at line %d\n", filename, line_number);
	printf("system halt\n");

	/* architecture specific halt */
	architecture_halt();

	return;
}

/*
 * kernel main entry point
 * architecture independent
 */
void
kernel(struct multiboot_data * data, unsigned int magic)
{
	/* clear video screen */
	video_clear();

	printf("Copyright (c) %s, Matthias Miller, Joerg Zinke (developers@khoros.org)\n", KERNEL_COPYRIGHT_YEAR);
	printf("khoros %s built %s %s\n", KERNEL_VERSION, __TIME__, __DATE__);
	
	/* validate and print multiboot data */
	multiboot(data, magic);

	/* architecture specific initialization */
	architecture_initialize(data->memory_upper);

	/* start scheduler */
	/* scheduler_run(); */

	printf("Idling...\n");
	while (1);

	return;
}
