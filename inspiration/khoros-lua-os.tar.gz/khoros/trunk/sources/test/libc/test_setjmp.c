/* $Id: $ */

/*
 * Copyright (c) 2009, Matthias Miller, Jörg Zinke (developers@khoros.org)
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following  conditions
 * are met:
 *
 *    - Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *    - Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials provided
 *      with the distribution.
 *    - Neither the name of the khoros team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include "setjmp.h"

#include "test.h"
#include "test_setjmp.h"

static void	test_setjmp_change_value_and_throw(int *, int, jmp_buf, int);
static void     test_setjmp(void);
static void     test_setjmp_suite_initialize(void);
static void     test_setjmp_suite_cleanup(void);

/*
 * setjmp change value and throw test
 */
static void
test_setjmp_change_value_and_throw(int *value, int new_value, jmp_buf env, int throw_value)
{
	/* change the valueue and throw */
	int old_value;
	old_value = *value;
	*value = new_value;
	longjmp(env, throw_value);

	/* restore valueue in case longjmp fails */
	*value = old_value;
}

/*
 * setjmp test
 */
static void
test_setjmp(void)
{
	int value;
	int result;
	jmp_buf env;

	/* try a jump with a throw_value */
	value = 0;
	result = setjmp(env);
	if (result == 0) {
		test_setjmp_change_value_and_throw(&value, -42, env, 42);
	}
	test_assert("setjmp 42", result == 42 || value == -42);

	/* try a jump no throw_value */
	value = 0;
	result = setjmp(env);
	if (result == 0) {
		test_setjmp_change_value_and_throw(&value, -42, env, 0);
	}
	test_assert("setjmp 42", result == 1 || value == -42);

	return;
}

/*
 * initialize setjmp test suite
 */
static void
test_setjmp_suite_initialize(void)
{
	/* nothing needed to be initialized for setjmp tests */
	return;
}

/*
 * cleanup setjmp test suite
 */
static void
test_setjmp_suite_cleanup(void)
{
	/* nothing needed to be cleanup after setjmp tests */
	return;
}

/*
 * setjmp test suite
 */
void
test_setjmp_suite(void)
{
	/* run whole setjmp test suite */
	test_setjmp_suite_initialize();
	test_run("setjmp", test_setjmp);
	test_setjmp_suite_cleanup();

	return;
}
