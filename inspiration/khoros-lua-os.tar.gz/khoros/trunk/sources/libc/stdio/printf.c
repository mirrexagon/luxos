#include <stdio.h>

int
printf(const char *format,...)
{
	return puts(format);
}
