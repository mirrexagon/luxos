#include <stdio.h>

#include "../../kernel/console.h"

int
puts(const char *str)
{
	return console_draw_str(str, 0, 0);
}
