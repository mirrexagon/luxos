#include <stdio.h>
#include <stdarg.h>
#include <sys/types.h>

int             vsnprintf(char *str, size_t count, const char *fmt, va_list arg);

int
sprintf(char *s, const char *format,...)
{
	const size_t    maxlen = 62 * 1024;
	va_list         ap;
	int             total;
	va_start(ap, format);
	total = vsnprintf(s, maxlen, format, ap);
	va_end(ap);
	return total;
}
