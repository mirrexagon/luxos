#include <string.h>

char           *
strncat(char *s, const char *ct, int n)
{
	char           *tmp = s;
	while (*tmp)
		tmp++;
	while (n-- && (*tmp++ = *ct++));
	*tmp = '\0';
	return s;
}
