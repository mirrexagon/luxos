#include <sys/types.h>
#include <string.h>

void           *
memcpy(void *s1, const void *s2, size_t n)
{
	char           *c1;
	const char     *c2;

	c1 = s1;
	c2 = s2;
	while (n--)
		*c1++ = *c2++;

	return s1;
}
