#include <string.h>

size_t
strcspn(const char *cs, const char *ct)
{
	const char     *tmp = cs;
	while (*tmp && strchr(ct, *tmp))
		tmp++;
	return tmp - cs;
}
