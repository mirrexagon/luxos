#include <string.h>

const char     *
strchr(const char *s, int c)
{
	unsigned char   uc = c;

	if (!s)
		return 0;

	while (*s) {
		if (*s == uc)
			return s;
		s++;
	}

	return 0;
}
