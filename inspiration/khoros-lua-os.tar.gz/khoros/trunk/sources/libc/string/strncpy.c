#include <string.h>

char           *
strncpy(char *s, const char *ct, int n)
{
	char           *tmp = s;
	while (n-- && (*tmp++ = *ct++));
	while (n--)
		*tmp++ = '\0';
	return s;
}
