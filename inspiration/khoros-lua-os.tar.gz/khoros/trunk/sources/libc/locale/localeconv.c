#include <locale.h>

struct lconv   *
localeconv(void)
{
	return 0;
}
