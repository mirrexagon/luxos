/* TODO: check casts, etc. */

#include <math.h>

double
floor(double d)
{
	int             i = d;

	if (d < 0.0 && d != i)
		i--;

	return i;
}
