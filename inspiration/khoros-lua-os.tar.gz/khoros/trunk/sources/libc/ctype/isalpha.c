#include <ctype.h>

int
isalpha(int c)
{
	unsigned char   uc = (unsigned char) c;
	return (uc >= 'a' && uc <= 'z') || (uc >= 'A' && uc <= 'Z');
}
