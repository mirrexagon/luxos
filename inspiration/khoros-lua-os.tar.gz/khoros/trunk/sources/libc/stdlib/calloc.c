#include <sys/types.h>
#include <stdlib.h>

#include "bget/bget.h"

void           *
calloc(size_t nelem, size_t elsize)
{
	return bgetz(nelem * elsize);
}
