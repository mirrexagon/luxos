#include <stdlib.h>

int
abs(int i)
{
	if (i < 0) {
		i = -i;
        }

	return i;
}
