#include <stdlib.h>

void
exit(int status)
{
        return;
}
