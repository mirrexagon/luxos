#include <sys/types.h>
#include <stdlib.h>

#include "bget/bget.h"

void           *
malloc(size_t size)
{
	return bget(size);
}
