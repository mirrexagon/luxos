#ifndef ERRNO_H
#define ERROR_H

extern int      __internal_errno;

#define errno (__internal_errno)

char           *
                strerror(int errnum);

#endif
