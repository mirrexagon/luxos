#ifndef __MEMORY_H__
#define __MEMORY_H__

void           *memcpy(void *, const void *, size_t);
int             memcmp(const void *, const void *, size_t);
void           *memchr(const void *, int, size_t);
void           *memset(void *, int, size_t);

#endif				/* #ifndef __MEMORY_H__ */
