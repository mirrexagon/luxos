#ifndef __MATH_H__
#define __MATH_H__

#define MATH_ERRNO	1
#define MATH_ERREXCEPT	2

#define math_errhandling MATH_ERRNO

double          floor(double);
double          pow(double, double);

#endif				/* #ifndef __MATH_H__ */
