#ifndef __STDIO_H__
#define __STDIO_h__

#include <types.h>

#define BUFSIZ  512

int     sprintf(char *, const char *,...);
int     printf(const char *,...);
int     puts(const char *);

#endif /* #ifndef __STDIO_H__ */
