#ifndef __STRING_H__
#define __STRING_H__

#include <types.h>

const char     *strchr(const char *, int);
size_t          strlen(const char *);
char           *strcpy(char *, const char *);
char           *strncpy(char *, const char *, int);
char           *strcat(char *, const char *);
char           *strncat(char *, const char *, int);
int             strcmp(const char *, const char *);
size_t          strcspn(const char *, const char *);
const char     *strstr(const char *, const char *);
void           *memcpy(void *, const void *, size_t);
int             memcmp(const void *, const void *, size_t);
int             strcoll(const char *, const char *);
void           *memchr(const void *, int, size_t);
void           *memset(void *, int, size_t);
char           *strpbrk(const char *, const char *);
char           *strrchr(const char *, int);

#endif /* #ifndef __STRING_H__ */
