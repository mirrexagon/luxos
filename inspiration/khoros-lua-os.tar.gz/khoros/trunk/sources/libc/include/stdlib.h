#ifndef __STDLIB_H__
#define __STDLIB_H__

#include <types.h>

#define EXIT_SUCCESS	0
#define EXIT_FAILURE	1

#define RAND_MAX	32767

#define HUGE_VAL 989898989

void            __meminit__(void *, size_t);
void            exit(int);
double          strtod(const char *, char **);
long            strtol(const char *, char **, int);
unsigned long   strtoul(const char *, char **, int);
void           *calloc(size_t, size_t);
void           *malloc(size_t);
void           *realloc(void *, size_t);
void            free(void *);
int             rand(void);
void            srand(unsigned int);
int             abs(int);

#endif  /* #ifndef __STDLIB_H__ */
