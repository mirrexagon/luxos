#ifndef __SYS_TYPES_H__
#define __SYS_TYPES_H__

#define NULL	0
typedef unsigned long size_t;

#endif /* #ifndef __SYS_TYPES_H__ */
