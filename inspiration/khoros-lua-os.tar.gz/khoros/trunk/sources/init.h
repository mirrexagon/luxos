#ifndef KERNEL_H
#define KERNEL_H

int
kernel_run(void);

#endif
