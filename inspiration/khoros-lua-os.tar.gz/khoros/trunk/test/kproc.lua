#!/usr/bin/lua

local tests = {
	-- Test duplicate process names.
	function(kproc)
		kproc.spawn('test', function() end)
		local ret, err = pcall(function()
			kproc.spawn('test', function() end)
		end)
		assert(err:find('Duplicate process name: test'))
		kproc.run()
	end,

	-- Test duplicate process names after the first completes.
	function(kproc)
		local x = 0
		kproc.spawn('test', function() x = 1 end)
		kproc.run()
		assert(x == 1)

		kproc.spawn('test', function() x = 2 end)
		kproc.run()
		assert(x == 2)
	end,

	-- Test ipc
	function(kproc)
		local awake = nil

		-- Block for a message.
		kproc.spawn('thread_a', function(ipc)
			awake = false
			local msg = ipc.recv{ name = 'wake_up' }
			assert(msg.value == true)
			msg = msg.reply('are_you_sure?').recv()
			assert(msg.value == 'yes')
			awake = true
		end)
		assert(awake == nil)
		assert(kproc.run() == 1)
		assert(awake == false)
		assert(kproc.run() == 0)
		assert(awake == false)

		-- Send a message.
		kproc.spawn('thread_b', function(ipc)
			local msg = ipc.send('thread_a', 'wake_up', true).recv()
			assert(msg.value == 'are_you_sure?')
			msg.reply('yes')
		end)
		while kproc.run() ~= 0 do end
		assert(awake == true)
	end,

	-- Test process-less IPC
	function(kproc)
		local a = kproc.make_ipc('ipc_a')
		local b = kproc.make_ipc('ipc_b')

		assert(kproc.run() == 0)

		local msg_a = a.send('ipc_b', 'wake_up', true)
		local msg_b = b.recv{}
		assert(msg_b.from == 'ipc_a')
		assert(msg_b.name == 'wake_up')
		assert(msg_b.value == true)
		msg_b = msg_b.reply(false)

		msg_a = msg_a.recv()
		assert(msg_a.from == 'ipc_b')
		assert(msg_a.name == 'wake_up')
		assert(msg_a.value == false)
	end,

	-- Test broadcast/subscribe.
	function(kproc)
		local a = kproc.make_ipc('ipc_a')
		local b = kproc.make_ipc('ipc_b')

		-- Try sending it to a process that isn't subscribed.
		a.broadcast('hello', 'world')
		assert(a.recv_async{} == nil)
		assert(b.recv_async{} == nil)

		-- Try subscribing to one's self.
		a.subscribe{ name = 'hello' }
		a.broadcast('hello', 'world')
		assert(a.recv_async{} == nil)
		assert(b.recv_async{} == nil)

		-- Try sending it to a process that is subscribed.
		b.subscribe{ name = 'hello', from = 'ipc_c' }
		a.broadcast('hello', 'world')
		assert(a.recv_async{} == nil)
		assert(b.recv_async{} == nil)

		local c = kproc.make_ipc('ipc_c')
		c.broadcast('hello', 'world')

		local msg = assert(a.recv_async{})
		assert(msg.from == 'ipc_c')
		assert(msg.name == 'hello')
		assert(msg.value ==  'world')

		local msg = assert(b.recv_async{})
		assert(msg.from == 'ipc_c')
		assert(msg.name == 'hello')
		assert(msg.value ==  'world')
	end,
}

for i,test in pairs(tests) do
	-- Initialize a very simplistic process manager.
	local func, err = loadfile('../modules/drivers/kproc.lua')
	local kproc = assert(func, err)()
	kproc.init(function(func, args)
		return {
			coroutine = coroutine.create(func),
			args = args
		}
	end,
	function(info)
		local ret, err = coroutine.resume(info.coroutine, info.args.ipc)
		assert(ret, err)
		return coroutine.status(info.coroutine) ~= 'dead'
	end)
	test(kproc)
end

